/**
 * ovice Reaction Deck - Content Script (v2.1)
 *
 * ovice画面上にフローティングリアクションパネルを表示。
 * 登録済みリアクション画像をクリックすると、injected.js 経由で
 * ovice.react() + ovice.chat() + ovice.commitReaction() を呼び出す。
 * パネル内のリアクション画像はドラッグ&ドロップで位置を入れ替え可能。
 * グリッドには空セルを置ける。リサイズは上下左右＋角の8方向。
 */
(function () {
  'use strict';
  if (document.getElementById('ovice-rs-root')) return;

  const STORAGE_KEY = 'oviceReactions';     // [{ id, name, dataUrl, sound }]
  const GRID_KEY    = 'oviceGridLayout';    // [reactionId | null, ...]
  const SETTINGS_KEY = 'oviceRsSettings';   // { maxCols, maxRows, panelOpacity }

  let reactions   = [];
  let gridLayout  = {};    // { "row,col": reactionId } — 2D座標ベース
  let panelOpen   = false;
  let panelOpacity = 75;
  let animateGif  = false;
  let panelScale  = 1;
  const newReactionIds = new Set(); // 未使用の新規リアクションID

  // パネル設定
  const ITEM_SIZE = 48;
  const GAP       = 6;
  const PAD       = 10;
  const PANEL_CHROME_H_FALLBACK = 36;
  const PANEL_GAP = 8;
  const MIN_COLS  = 3;
  let   MAX_COLS  = 10;
  const MIN_ROWS  = 2;
  let   MAX_ROWS  = 10;
  // パネルサイズは常に MAX_COLS × MAX_ROWS（設定値）を使用
  let isBelowMode = false;

  // ── injected.js をページコンテキストに注入 ────────────────────
  function injectScript() {
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL('injected.js');
    (document.head || document.documentElement).appendChild(script);
    script.onload = () => script.remove();
  }
  injectScript();

  // ── リアクションパネルを自動で開く ────────────────────────
  (function autoOpenReactionPanel() {
    function tryOpenReaction() {
      const btn = document.querySelector('[data-testid="reactions-menu"]');
      if (btn && btn.dataset.state === 'closed') {
        btn.click();
        return true;
      }
      return false;
    }

    if (!tryOpenReaction()) {
      const observer = new MutationObserver(() => {
        if (tryOpenReaction()) observer.disconnect();
      });
      observer.observe(document.body, { childList: true, subtree: true });
      setTimeout(() => observer.disconnect(), 15000);
    }
  })();

  // ── 「ブラウザでの利用を継続」を自動クリック ───────────────
  (function autoDismissAppModal() {
    const TARGET_TEXT = 'ブラウザでの利用を継続';
    function tryClick() {
      for (const el of document.querySelectorAll('button, a, [role="button"]')) {
        if (el.textContent.trim() === TARGET_TEXT) { el.click(); return true; }
      }
      return false;
    }
    if (!tryClick()) {
      const obs = new MutationObserver(() => { if (tryClick()) obs.disconnect(); });
      obs.observe(document.body, { childList: true, subtree: true });
      setTimeout(() => obs.disconnect(), 10000);
    }
  })();

  // ── ヘルパー ──────────────────────────────────────────────────
  function getReactionById(id) {
    return reactions.find(r => r.id === id) || null;
  }

  function calcWidth(cols)      { return PAD * 2 + cols * ITEM_SIZE + (cols - 1) * GAP; }
  function calcGridHeight(rows) { return rows * ITEM_SIZE + (rows - 1) * GAP; }

  /**
   * パネルがビューポートに収まるようトグルボタン位置を補正する。
   * ドラッグ終了時に呼ばれ、スムーズにスナップバックする。
   */
  function snapToggleToFit() {
    const root   = document.getElementById('ovice-rs-root');
    const toggle = document.getElementById('ovice-rs-toggle');
    const panel  = document.getElementById('ovice-rs-panel');
    if (!root || !toggle || !panel) return;

    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const margin = 8;
    const tRect = toggle.getBoundingClientRect();
    const tw = toggle.offsetWidth;
    const th = toggle.offsetHeight;

    // パネルのスケール済み寸法を実測（レイアウトサイズ × scale）
    const panelW = panel.offsetWidth * panelScale;
    const panelH = panel.offsetHeight * panelScale;

    // applyPanelSize のクランプなしでパネルの本来の端座標を計算
    // 水平: パネル右端 = トグル右端、パネル左端 = トグル右端 - panelW
    const panelRight = tRect.right;
    const panelLeft  = tRect.right - panelW;

    // 垂直: isBelowMode ならトグル下 + GAP、そうでなければトグル上 - GAP - panelH
    let panelTop, panelBottom;
    if (isBelowMode) {
      panelTop    = tRect.bottom + PANEL_GAP;
      panelBottom = panelTop + panelH;
    } else {
      panelBottom = tRect.top - PANEL_GAP;
      panelTop    = panelBottom - panelH;
    }

    let nx = tRect.left;
    let ny = tRect.top;

    // はみ出し分だけトグルを補正
    if (panelLeft < margin)       nx += (margin - panelLeft);
    if (panelRight > vw - margin) nx -= (panelRight - (vw - margin));
    if (panelTop < margin)        ny += (margin - panelTop);
    if (panelBottom > vh - margin) ny -= (panelBottom - (vh - margin));

    // トグル自体もビューポート内に
    nx = Math.max(0, Math.min(vw - tw, nx));
    ny = Math.max(0, Math.min(vh - th, ny));

    // スムーズにスナップバック
    root.style.transition = 'left 0.2s ease, top 0.2s ease';
    root.style.left = nx + 'px';
    root.style.top = ny + 'px';
    setTimeout(() => { root.style.transition = ''; }, 220);
  }

  // ── gridLayout ヘルパー（2D座標ベース）─────────────────────────
  function gridKey(row, col) { return row + ',' + col; }

  /** gridLayout を reactions に同期。削除分は除去、新規は空きセルに追加 */
  function syncGridLayout() {
    const reactionIds = new Set(reactions.map(r => r.id));
    const inLayout = new Set();

    // 削除されたリアクションを除去
    for (const key of Object.keys(gridLayout)) {
      if (!reactionIds.has(gridLayout[key])) {
        delete gridLayout[key];
      } else {
        inLayout.add(gridLayout[key]);
      }
    }

    // 新規リアクションを空きセルに追加
    reactions.forEach(r => {
      if (!inLayout.has(r.id)) {
        const pos = findEmptyCell();
        if (pos) gridLayout[gridKey(pos.row, pos.col)] = r.id;
        newReactionIds.add(r.id);
      }
    });
  }

  /** グリッド内の最初の空きセルを探す */
  function findEmptyCell() {
    for (let row = 0; row < MAX_ROWS; row++) {
      for (let col = 0; col < MAX_COLS; col++) {
        if (!gridLayout[gridKey(row, col)]) return { row, col };
      }
    }
    return null;
  }

  /** リアクションが配置されている最大行・列を返す */
  function getMaxOccupied() {
    let maxRow = 0, maxCol = 0;
    for (const key of Object.keys(gridLayout)) {
      const [r, c] = key.split(',').map(Number);
      maxRow = Math.max(maxRow, r);
      maxCol = Math.max(maxCol, c);
    }
    return { maxRow, maxCol };
  }

  function saveGridLayout(cb) {
    chrome.storage.local.set({ [GRID_KEY]: gridLayout }, cb);
  }

  // ── 初期化 ────────────────────────────────────────────────────
  chrome.storage.local.get([STORAGE_KEY, GRID_KEY, SETTINGS_KEY], (result) => {
    reactions = result[STORAGE_KEY] || [];
    const savedGrid = result[GRID_KEY];

    // 旧フォーマット（配列）からの移行
    if (Array.isArray(savedGrid)) {
      gridLayout = {};
      const oldCols = 10; // 旧デフォルト列数
      savedGrid.forEach((id, idx) => {
        if (id != null) {
          const row = Math.floor(idx / oldCols);
          const col = idx % oldCols;
          gridLayout[gridKey(row, col)] = id;
        }
      });
      // 移行後の新フォーマットを保存
      chrome.storage.local.set({ [GRID_KEY]: gridLayout });
    } else {
      gridLayout = savedGrid || {};
    }

    const settings = result[SETTINGS_KEY] || {};
    panelOpacity = settings.panelOpacity != null ? settings.panelOpacity : 75;
    animateGif = !!settings.animateGif;
    panelScale = settings.panelScale != null ? settings.panelScale : 1;
    if (settings.maxCols) MAX_COLS = Math.max(MIN_COLS, settings.maxCols);
    if (settings.maxRows) MAX_ROWS = Math.max(MIN_ROWS, settings.maxRows);

    syncGridLayout();
    buildUI();
  });

  // ストレージの変更を監視（popup から追加/削除された場合）
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;

    // GRID_KEY が同時に変更された場合（インポート）はそちらを優先
    if (changes[GRID_KEY]) {
      const newGrid = changes[GRID_KEY].newValue;
      if (newGrid && typeof newGrid === 'object' && !Array.isArray(newGrid)) {
        gridLayout = newGrid;
      }
    }

    if (changes[STORAGE_KEY]) {
      reactions = changes[STORAGE_KEY].newValue || [];
      syncGridLayout();
      if (!changes[GRID_KEY]) {
        // グリッドが同時に変更されていない場合のみ保存
        saveGridLayout(() => renderGrid());
      } else {
        renderGrid();
      }
    }

    if (changes[SETTINGS_KEY]) {
      const s = changes[SETTINGS_KEY].newValue || {};
      panelOpacity = s.panelOpacity != null ? s.panelOpacity : 75;
      animateGif = !!s.animateGif;
      panelScale = s.panelScale != null ? s.panelScale : 1;
      if (s.maxCols) MAX_COLS = Math.max(MIN_COLS, s.maxCols);
      if (s.maxRows) MAX_ROWS = Math.max(MIN_ROWS, s.maxRows);
      applyPanelOpacity();
      // MAX が変わったらパネルサイズとグリッドを再構築
      if (panelOpen) {
        applyPanelSize();
      }
      renderGrid();
    }
  });

  // ── トグルアイコン ──────────────────────────────────────────────
  const ICON_SMILE = `<svg width="22" height="22" viewBox="0 0 24 24" fill="none"
    stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <circle cx="12" cy="12" r="10"/>
    <path d="M8 14s1.5 2 4 2 4-2 4-2"/>
    <line x1="9" y1="9" x2="9.01" y2="9"/>
    <line x1="15" y1="9" x2="15.01" y2="9"/>
  </svg>`;
  const ICON_CLOSE = `<svg width="22" height="22" viewBox="0 0 24 24" fill="none"
    stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <line x1="18" y1="6" x2="6" y2="18"/>
    <line x1="6" y1="6" x2="18" y2="18"/>
  </svg>`;

  // ── UI構築 ────────────────────────────────────────────────────
  function buildUI() {
    const root = document.createElement('div');
    root.id = 'ovice-rs-root';

    // トグルボタン
    const toggle = document.createElement('button');
    toggle.id = 'ovice-rs-toggle';
    toggle.title = 'リアクションパネル';
    toggle.innerHTML = ICON_SMILE;

    // ドラッグ移動
    const DRAG_THRESHOLD = 5;
    let wasDragging = false;

    function attachDrag(handle) {
      let sx = 0, sy = 0, rx = 0, ry = 0, dragging = false;
      handle.addEventListener('mousedown', (e) => {
        if (e.button !== 0) return;
        dragging = false;
        sx = e.clientX; sy = e.clientY;
        const rect = root.getBoundingClientRect();
        rx = rect.left; ry = rect.top;
        root.style.right = 'auto'; root.style.bottom = 'auto';
        root.style.left = rx + 'px'; root.style.top = ry + 'px';

        function onMove(ev) {
          const dx = ev.clientX - sx, dy = ev.clientY - sy;
          if (!dragging && Math.hypot(dx, dy) > DRAG_THRESHOLD) {
            dragging = true; wasDragging = true;
            toggle.classList.add('ovice-rs-toggle--dragging');
          }
          if (!dragging) return;
          // ドラッグ中はビューポート内クランプのみ（パネルはみ出しは許容）
          const nx = Math.max(0, Math.min(window.innerWidth - root.offsetWidth, rx + dx));
          const ny = Math.max(0, Math.min(window.innerHeight - root.offsetHeight, ry + dy));
          root.style.left = nx + 'px'; root.style.top = ny + 'px';
          if (panelOpen) applyPanelSize();
        }
        function onUp() {
          document.removeEventListener('mousemove', onMove);
          document.removeEventListener('mouseup', onUp);
          toggle.classList.remove('ovice-rs-toggle--dragging');
          // パネルが開いている場合、パネルが収まる位置にスナップバック
          if (panelOpen) {
            snapToggleToFit();
            applyPanelSize();
          }
          dragging = false;
        }
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
      });
    }
    attachDrag(toggle);

    toggle.addEventListener('click', (e) => {
      if (wasDragging) { wasDragging = false; return; }
      e.stopPropagation();
      togglePanel();
    });

    // パネル本体
    const panel = document.createElement('div');
    panel.id = 'ovice-rs-panel';

    // パネル内部コンテンツ（リサイズハンドルの外）
    const panelInner = document.createElement('div');
    panelInner.style.cssText = 'display:flex;flex-direction:column;overflow:hidden;border-radius:14px;height:100%;min-height:0;';
    panelInner.innerHTML = `
      <div class="ovice-rs-header" id="ovice-rs-header">
        <span>リアクション</span>
      </div>
      <div class="ovice-rs-grid" id="ovice-rs-grid"></div>
      <div class="ovice-rs-empty" id="ovice-rs-empty">
        拡張機能アイコンから<br>リアクション画像を追加してください
      </div>
    `;
    panel.appendChild(panelInner);

    // ── スケールリサイズハンドル（四隅）─────────────────────────────
    ['top-left', 'top-right', 'bottom-left', 'bottom-right'].forEach(pos => {
      const handle = document.createElement('div');
      handle.className = 'ovice-rs-scale-handle ovice-rs-scale-handle--' + pos;
      handle.dataset.corner = pos;
      panel.appendChild(handle);
    });

    root.appendChild(panel);
    root.appendChild(toggle);
    document.body.appendChild(root);

    attachDrag(panel.querySelector('.ovice-rs-header'));

    // ── パネルへのファイルドロップ（画像追加）──────────────────────
    setupPanelFileDrop(panel);

    // ── 右クリックメニュー（capture で ovice より先に捕まえる）───────
    root.addEventListener('contextmenu', (e) => {
      const item = e.target.closest('.ovice-rs-item');
      if (!item) return;
      e.preventDefault();
      e.stopPropagation();
      const key = item.dataset.key;
      const id = gridLayout[key];
      const r = id ? getReactionById(id) : null;
      if (r) showDeleteMenu(e.clientX, e.clientY, r, key);
    }, true);

    // ── スケールドラッグ（四隅共通・対角固定）──────────────────────
    panel.querySelectorAll('.ovice-rs-scale-handle').forEach(handle => {
      handle.addEventListener('mousedown', (e) => {
        e.preventDefault();
        e.stopPropagation();

        const corner = handle.dataset.corner;
        const dirX = corner.includes('right') ? 1 : -1;
        const dirY = corner.includes('bottom') ? 1 : -1;
        const startX = e.clientX;
        const startY = e.clientY;
        const startScale = panelScale;

        const rect = panel.getBoundingClientRect();
        const baseDiag = Math.sqrt(rect.width * rect.width + rect.height * rect.height);

        // 対角（固定する角）のビューポート座標
        const anchorVX = corner.includes('right') ? rect.left : rect.right;
        const anchorVY = corner.includes('bottom') ? rect.top : rect.bottom;

        // パネルの非スケール寸法
        const unscaledW = rect.width / startScale;
        const unscaledH = rect.height / startScale;

        // transform-origin を対角に設定し、CSS位置をその角に合わせる
        const originX = corner.includes('right') ? 'left' : 'right';
        const originY = corner.includes('bottom') ? 'top' : 'bottom';
        panel.style.transformOrigin = originY + ' ' + originX;

        if (originX === 'left') {
          panel.style.left = anchorVX + 'px';
          panel.style.right = 'auto';
        } else {
          panel.style.right = (window.innerWidth - anchorVX) + 'px';
          panel.style.left = 'auto';
        }
        if (originY === 'top') {
          panel.style.top = anchorVY + 'px';
          panel.style.bottom = 'auto';
        } else {
          panel.style.bottom = (window.innerHeight - anchorVY) + 'px';
          panel.style.top = 'auto';
        }

        function onMove(ev) {
          ev.stopPropagation();
          const dx = (ev.clientX - startX) * dirX;
          const dy = (ev.clientY - startY) * dirY;
          const diag = (dx + dy) / 2;
          const newScale = Math.max(0.5, Math.min(2, startScale + diag / baseDiag));
          panelScale = Math.round(newScale * 100) / 100;
          panel.style.transform = `scale(${panelScale})`;
        }
        function onUp() {
          document.removeEventListener('mousemove', onMove);
          document.removeEventListener('mouseup', onUp);

          // パネルの現在位置からトグルボタンの位置を逆算して移動
          const panelRect = panel.getBoundingClientRect();
          const toggleEl = document.getElementById('ovice-rs-toggle');
          const rootEl = document.getElementById('ovice-rs-root');
          if (toggleEl && rootEl) {
            // トグル右端をパネル右端に揃える
            const newToggleRight = panelRect.right - toggleEl.offsetWidth;
            // トグルはパネルの上or下に PANEL_GAP 分離して配置
            const newToggleY = isBelowMode
              ? panelRect.top - PANEL_GAP - toggleEl.offsetHeight
              : panelRect.bottom + PANEL_GAP;
            rootEl.style.left = Math.max(0, newToggleRight) + 'px';
            rootEl.style.top = Math.max(0, newToggleY) + 'px';
            rootEl.style.right = 'auto';
            rootEl.style.bottom = 'auto';
          }

          // デフォルトの位置配置・origin に戻す
          applyPanelSize();
          chrome.storage.local.get([SETTINGS_KEY], (r) => {
            const s = r[SETTINGS_KEY] || {};
            s.panelScale = panelScale;
            chrome.storage.local.set({ [SETTINGS_KEY]: s });
          });
        }
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
      });
    });

    applyPanelSize();
    renderGrid();
  }

  // ── パネルサイズ適用 ─────────────────────────────────────────

  /**
   * パネルのサイズと位置を適用（position: fixed ベース）。
   * トグルボタンの viewport 座標を基準に配置し、
   * ビューポート端からはみ出さないようクランプする。
   */
  function applyPanelScale() {
    const panel = document.getElementById('ovice-rs-panel');
    if (panel) {
      panel.style.transform = `scale(${panelScale})`;
      panel.style.transformOrigin = isBelowMode ? 'top right' : 'bottom right';
    }
  }

  function applyPanelOpacity() {
    const panel = document.getElementById('ovice-rs-panel');
    if (panel) {
      const alpha = panelOpacity / 100;
      panel.style.background = `rgba(20, 20, 28, ${alpha})`;
      panel.style.backdropFilter = 'none';
      panel.style.webkitBackdropFilter = 'none';
    }
  }

  function applyPanelSize() {
    const panel  = document.getElementById('ovice-rs-panel');
    const toggle = document.getElementById('ovice-rs-toggle');
    if (!panel || !toggle) return;

    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const margin = 8;

    // ヘッダーの実測高さ（まだ非表示の場合はフォールバック）
    const header = panel.querySelector('.ovice-rs-header');
    const chromeH = header ? header.offsetHeight : PANEL_CHROME_H_FALLBACK;

    // パネルサイズは常に MAX_COLS × MAX_ROWS
    const cols = MAX_COLS;
    const rows = MAX_ROWS;

    const panelW = calcWidth(cols);
    const panelH = chromeH + calcGridHeight(rows) + PAD * 2;

    // ── ビューポートに収まるようサイズをクランプ ─────────────────
    const maxW = vw - margin * 2;
    const maxH = vh - margin * 2;
    const finalW = Math.min(panelW, maxW);
    const finalH = Math.min(panelH, maxH);

    // ── トグルの viewport 座標 ────────────────────────────────────
    const tRect = toggle.getBoundingClientRect();

    // ── 水平位置: パネル右端をトグル右端に揃え、viewport 内にクランプ ──
    // transform-origin が right 側なので、視覚的右端 = CSS右端
    // 視覚的幅はスケール適用後のサイズ
    const scaledW = finalW * panelScale;
    const scaledH = finalH * panelScale;
    let cssRight = vw - tRect.right;
    if (tRect.right - scaledW < margin) {
      cssRight = vw - scaledW - margin;
    }
    if (cssRight < margin) cssRight = margin;

    // ── 明示的にサイズと overflow を inline style で強制設定 ──────
    panel.style.width    = finalW + 'px';
    panel.style.height   = finalH + 'px';
    panel.style.overflow = 'hidden';
    panel.style.right    = cssRight + 'px';
    panel.style.left     = 'auto';

    // panelInner にも明示サイズ + overflow:hidden を設定（二重クリップ）
    const panelInner = panel.firstElementChild;
    if (panelInner) {
      panelInner.style.width    = (finalW - 2) + 'px';   // border 分を差し引く
      panelInner.style.height   = (finalH - 2) + 'px';
      panelInner.style.overflow = 'hidden';
    }

    // ── 垂直位置 ─────────────────────────────────────────────────
    if (isBelowMode) {
      // transform-origin: top right → 視覚的上端 = CSS上端
      let cssTop = tRect.bottom + PANEL_GAP;
      if (cssTop + scaledH > vh - margin) cssTop = vh - margin - scaledH;
      if (cssTop < margin) cssTop = margin;
      panel.style.top    = cssTop + 'px';
      panel.style.bottom = 'auto';
    } else {
      // transform-origin: bottom right → 視覚的下端 = CSS下端
      let cssBottom = vh - tRect.top + PANEL_GAP;
      if (cssBottom + scaledH > vh - margin) cssBottom = vh - scaledH - margin;
      if (cssBottom < margin) cssBottom = margin;
      panel.style.bottom = cssBottom + 'px';
      panel.style.top    = 'auto';
    }

    // ── グリッドのサイズを残りスペースに合わせる ─────────────────
    const grid = document.getElementById('ovice-rs-grid');
    if (grid) {
      grid.style.gridTemplateColumns = `repeat(${cols}, minmax(48px, 1fr))`;
      const gridMaxH = finalH - chromeH;
      // box-sizing:border-box なので padding(上下20px)込みの値を設定
      grid.style.maxHeight = Math.max(calcGridHeight(MIN_ROWS) + PAD * 2, gridMaxH) + 'px';
    }

    applyPanelOpacity();
    applyPanelScale();
  }

  // ── ファイルドロップで画像追加 ───────────────────────────────────
  const MAX_IMG_SIZE = 128;

  function processImageFile(file, callback) {
    const reader = new FileReader();
    reader.onload = (e) => {
      if (file.type === 'image/gif') { callback(e.target.result); return; }
      const img = new Image();
      img.onload = () => {
        let url = e.target.result;
        if (img.width > MAX_IMG_SIZE || img.height > MAX_IMG_SIZE) {
          const s = MAX_IMG_SIZE / Math.max(img.width, img.height);
          const c = document.createElement('canvas');
          c.width = Math.round(img.width * s);
          c.height = Math.round(img.height * s);
          c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
          url = c.toDataURL('image/png');
        }
        callback(url);
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);
  }

  function addFilesToReactions(files, targetCellKey) {
    const images = files.filter(f => /^image\/(png|gif|webp|jpeg)$/.test(f.type));
    if (images.length === 0) return;

    // デフォルト効果音を取得
    chrome.storage.local.get([SETTINGS_KEY], (result) => {
      const defaultSound = (result[SETTINGS_KEY] || {}).defaultSound
        || '/assets/reaction/sound/love.mp3';
      let processed = 0;
      // ドロップ先セルのキューを作る（1個目はドロップ先、以降は空きセル）
      let nextCellKey = targetCellKey && !gridLayout[targetCellKey] ? targetCellKey : null;

      images.forEach((file, idx) => {
        processImageFile(file, (dataUrl) => {
          const baseName = file.name.replace(/\.[^.]+$/, '').substring(0, 20);
          const newId = Date.now().toString() + '_' + Math.random().toString(36).slice(2, 6);
          reactions.push({
            id: newId,
            name: baseName,
            dataUrl,
            sound: defaultSound,
          });

          // 1個目でドロップ先セルが空なら直接配置
          if (idx === 0 && nextCellKey) {
            gridLayout[nextCellKey] = newId;
            newReactionIds.add(newId);
          }

          processed++;
          if (processed === images.length) {
            // 直接配置しなかった分は syncGridLayout で空きセルに入る
            syncGridLayout();
            chrome.storage.local.set({
              [STORAGE_KEY]: reactions,
              [GRID_KEY]: gridLayout,
            }, () => renderGrid());
          }
        });
      });
    });
  }

  function setupPanelFileDrop(panel) {
    const hasFiles = (e) => Array.from(e.dataTransfer?.types || []).includes('Files');
    let dragDepth = 0;

    panel.addEventListener('dragenter', (e) => {
      if (!hasFiles(e)) return;
      e.preventDefault();
      e.stopPropagation();
      dragDepth++;
      panel.classList.add('ovice-rs-panel--file-over');
    });
    // capture: true でセルの stopPropagation より先にファイルドロップを処理
    panel.addEventListener('dragover', (e) => {
      if (!hasFiles(e)) return;
      e.preventDefault();
      e.stopPropagation();
      e.dataTransfer.dropEffect = 'copy';
    }, true);
    panel.addEventListener('dragleave', (e) => {
      if (!hasFiles(e)) return;
      e.stopPropagation();
      dragDepth = Math.max(0, dragDepth - 1);
      if (dragDepth === 0) panel.classList.remove('ovice-rs-panel--file-over');
    });
    panel.addEventListener('drop', (e) => {
      if (!hasFiles(e)) return;
      e.preventDefault();
      e.stopPropagation();
      dragDepth = 0;
      panel.classList.remove('ovice-rs-panel--file-over');
      // ドロップ先のセルキーを取得（空セル or リアクションアイテム）
      const cell = e.target.closest('.ovice-rs-cell-empty, .ovice-rs-item');
      const targetKey = cell?.dataset?.key || null;
      addFilesToReactions(Array.from(e.dataTransfer.files || []), targetKey);
    }, true);
  }

  // ── グリッド描画 ─────────────────────────────────────────────
  function renderGrid() {
    const grid  = document.getElementById('ovice-rs-grid');
    const empty = document.getElementById('ovice-rs-empty');
    if (!grid || !empty) return;
    grid.innerHTML = '';

    // リアクションが1つもなければ空メッセージ
    if (reactions.length === 0) {
      grid.style.display = 'none';
      empty.style.display = 'block';
      return;
    }
    grid.style.display = 'grid';
    empty.style.display = 'none';

    for (let row = 0; row < MAX_ROWS; row++) {
      for (let col = 0; col < MAX_COLS; col++) {
        const key = gridKey(row, col);
        const id = gridLayout[key];
        const r = id ? getReactionById(id) : null;

        if (!r) {
          // ── 空セル ────────────────────────────
          const cell = document.createElement('div');
          cell.className = 'ovice-rs-cell-empty';
          cell.dataset.key = key;

          cell.addEventListener('dragover', (e) => {
            e.preventDefault();
            e.stopPropagation();
            e.dataTransfer.dropEffect = 'move';
            cell.classList.add('ovice-rs-item--over');
          });
          cell.addEventListener('dragleave', () => cell.classList.remove('ovice-rs-item--over'));
          cell.addEventListener('drop', (e) => {
            e.preventDefault();
            e.stopPropagation();
            cell.classList.remove('ovice-rs-item--over');
            const fromKey = e.dataTransfer.getData('text/plain');
            if (!fromKey || fromKey === key) return;
            gridLayout[key] = gridLayout[fromKey];
            delete gridLayout[fromKey];
            saveGridLayout(() => renderGrid());
          });

          grid.appendChild(cell);
          continue;
        }

        // ── リアクションアイテム ────────────────
        const item = document.createElement('button');
        item.className = 'ovice-rs-item';
        item.title = r.name || '';
        item.draggable = true;
        item.dataset.key = key;

        const img = document.createElement('img');
        img.alt = r.name || '';
        img.draggable = false;
        // GIF: animateGif 設定に応じて常時アニメーション or ホバー時のみ
        if (!animateGif && r.dataUrl && r.dataUrl.startsWith('data:image/gif')) {
          const tmpImg = new Image();
          tmpImg.onload = () => {
            const canvas = document.createElement('canvas');
            canvas.width = tmpImg.width;
            canvas.height = tmpImg.height;
            canvas.getContext('2d').drawImage(tmpImg, 0, 0);
            const staticUrl = canvas.toDataURL('image/png');
            img.src = staticUrl;
            item.addEventListener('mouseenter', () => { img.src = r.dataUrl; });
            item.addEventListener('mouseleave', () => { img.src = staticUrl; });
          };
          tmpImg.src = r.dataUrl;
        } else {
          img.src = r.dataUrl;
        }
        item.appendChild(img);

        // 新規追加バッジ
        if (newReactionIds.has(r.id)) {
          const badge = document.createElement('span');
          badge.className = 'ovice-rs-new-badge';
          item.appendChild(badge);
        }

        item.addEventListener('click', (e) => {
          e.stopPropagation();
          sendReaction(r);
          // 新規バッジを消す
          if (newReactionIds.has(r.id)) {
            newReactionIds.delete(r.id);
            const badge = item.querySelector('.ovice-rs-new-badge');
            if (badge) badge.remove();
          }
          item.classList.add('ovice-rs-item--sent');
          setTimeout(() => item.classList.remove('ovice-rs-item--sent'), 400);
        });

        // ── ドラッグ&ドロップ（位置スワップ）──────────────────────
        item.addEventListener('dragstart', (e) => {
          e.stopPropagation();
          e.dataTransfer.effectAllowed = 'move';
          e.dataTransfer.setData('text/plain', key);
          item.classList.add('ovice-rs-item--dragging');
          newReactionIds.delete(r.id);
        });
        item.addEventListener('dragend', () => {
          item.classList.remove('ovice-rs-item--dragging');
          grid.querySelectorAll('.ovice-rs-item--over').forEach(el =>
            el.classList.remove('ovice-rs-item--over')
          );
        });
        item.addEventListener('dragover', (e) => {
          e.preventDefault();
          e.stopPropagation();
          e.dataTransfer.dropEffect = 'move';
          item.classList.add('ovice-rs-item--over');
        });
        item.addEventListener('dragleave', () => {
          item.classList.remove('ovice-rs-item--over');
        });
        item.addEventListener('drop', (e) => {
          e.preventDefault();
          e.stopPropagation();
          item.classList.remove('ovice-rs-item--over');
          const fromKey = e.dataTransfer.getData('text/plain');
          if (!fromKey || fromKey === key) return;
          const tmp = gridLayout[key];
          gridLayout[key] = gridLayout[fromKey];
          if (tmp) { gridLayout[fromKey] = tmp; } else { delete gridLayout[fromKey]; }
          saveGridLayout(() => renderGrid());
        });

        grid.appendChild(item);
      }
    }
  }

  // ── 右クリック削除メニュー ────────────────────────────────────
  let activeMenu = null;
  function showDeleteMenu(x, y, reaction, gridKey) {
    dismissMenu();
    const menu = document.createElement('div');
    menu.className = 'ovice-rs-ctx-menu';

    const btn = document.createElement('button');
    btn.textContent = '「' + (reaction.name || 'reaction') + '」を削除';
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      dismissMenu();
      reactions = reactions.filter(r => r.id !== reaction.id);
      delete gridLayout[gridKey];
      newReactionIds.delete(reaction.id);
      chrome.storage.local.set({
        [STORAGE_KEY]: reactions,
        [GRID_KEY]: gridLayout,
      }, () => renderGrid());
    });
    menu.appendChild(btn);

    // ビューポート内に収める
    document.body.appendChild(menu);
    const rect = menu.getBoundingClientRect();
    const mx = Math.min(x, window.innerWidth - rect.width - 4);
    const my = Math.min(y, window.innerHeight - rect.height - 4);
    menu.style.left = mx + 'px';
    menu.style.top = my + 'px';

    activeMenu = menu;
    setTimeout(() => {
      document.addEventListener('mousedown', dismissOnOutside);
    }, 0);
  }
  function dismissMenu() {
    if (activeMenu) { activeMenu.remove(); activeMenu = null; }
    document.removeEventListener('mousedown', dismissOnOutside);
  }
  function dismissOnOutside(e) {
    if (activeMenu && !activeMenu.contains(e.target)) dismissMenu();
  }

  // ── リアクション送信 ─────────────────────────────────────────
  function sendReaction(reaction) {
    window.dispatchEvent(new CustomEvent('__ovice_rs_send_reaction', {
      detail: {
        name: reaction.name || 'custom',
        iconSrc: reaction.dataUrl,
        sound: reaction.sound || '/assets/reaction/sound/love.mp3',
      }
    }));
  }

  // ── パネル開閉 ──────────────────────────────────────────────
  function togglePanel() { panelOpen ? closePanel() : openPanel(); }

  function openPanel() {
    panelOpen = true;
    const p = document.getElementById('ovice-rs-panel');
    const toggle = document.getElementById('ovice-rs-toggle');
    if (p && toggle) {
      const tRect = toggle.getBoundingClientRect();
      // トグルが画面上半分にあるなら下に開く
      isBelowMode = tRect.top < window.innerHeight / 2;
      // スケールを先に適用してからパネルを表示（チラつき防止）
      applyPanelScale();
      p.classList.add('ovice-rs-panel--open');
      applyPanelSize();
      snapToggleToFit();
      applyPanelSize();
    }
    toggle?.classList.add('ovice-rs-toggle--active');
    if (toggle) toggle.innerHTML = ICON_CLOSE;
  }

  function closePanel() {
    panelOpen = false;
    const p = document.getElementById('ovice-rs-panel');
    p?.classList.remove('ovice-rs-panel--open');
    isBelowMode = false;
    const toggle = document.getElementById('ovice-rs-toggle');
    if (!popupOpen) {
      toggle?.classList.remove('ovice-rs-toggle--active');
    }
    if (toggle) toggle.innerHTML = ICON_SMILE;
  }

  // ── ovice 標準リアクションの GIF 静止化 ──────────────────────────
  // ovice ネイティブのリアクションパネル内の GIF 画像を静止表示にし、
  // ホバー時のみアニメーション再生する。
  (function freezeOviceNativeGifs() {
    function processGifImages() {
      const imgs = document.querySelectorAll('button.reactionButton img');
      imgs.forEach(img => {
        if (!img.src.includes('.gif') && !img.dataset.oviceRsFrozen) return;

        // animateGif ON: 凍結済みなら元に戻す
        if (animateGif) {
          if (img.dataset.oviceRsFrozen && img.dataset.oviceRsGifSrc) {
            img.src = img.dataset.oviceRsGifSrc;
            delete img.dataset.oviceRsFrozen;
            delete img.dataset.oviceRsGifSrc;
            const btn = img.closest('button');
            if (btn) {
              btn.replaceWith(btn.cloneNode(true)); // イベントリスナーを除去
            }
          }
          return;
        }

        // animateGif OFF: 未凍結のGIFを静止化
        if (img.dataset.oviceRsFrozen) return;
        img.dataset.oviceRsFrozen = 'true';

        const gifSrc = img.src;
        img.dataset.oviceRsGifSrc = gifSrc;
        const tmpImg = new Image();
        tmpImg.crossOrigin = 'anonymous';
        tmpImg.onload = () => {
          const canvas = document.createElement('canvas');
          canvas.width = tmpImg.width;
          canvas.height = tmpImg.height;
          canvas.getContext('2d').drawImage(tmpImg, 0, 0);
          try {
            const staticUrl = canvas.toDataURL('image/png');
            img.src = staticUrl;
            const btn = img.closest('button');
            if (btn) {
              btn.addEventListener('mouseenter', () => { img.src = gifSrc; });
              btn.addEventListener('mouseleave', () => { img.src = staticUrl; });
            }
          } catch (e) {
            console.warn('[ovice RS] Cannot freeze native GIF:', e);
          }
        };
        tmpImg.src = gifSrc;
      });
    }

    // DOM 変更を監視して、リアクションパネルが表示されたタイミングで処理
    const observer = new MutationObserver(() => processGifImages());
    observer.observe(document.body, { childList: true, subtree: true });
    // 初回実行
    processGifImages();
  })();

  // ── ポップアップ開閉検知 ─────────────────────────────────────
  let popupOpen = false;
  chrome.runtime.onConnect.addListener((port) => {
    if (port.name === 'popup') {
      popupOpen = true;
      const toggle = document.getElementById('ovice-rs-toggle');
      toggle?.classList.add('ovice-rs-toggle--active');
      port.onDisconnect.addListener(() => {
        popupOpen = false;
        if (!panelOpen) {
          document.getElementById('ovice-rs-toggle')?.classList.remove('ovice-rs-toggle--active');
        }
      });
    }
  });
})();
