/**
 * ovice Reaction Deck - Injected Script (v2.1)
 * ページコンテキストで動作。
 * content.js からカスタムイベント経由でリアクション送信指示を受け取り、
 * window.ovice の内部メソッドを使って Canvas 上にリアクションを表示する。
 * 効果音もこのスクリプトで再生する（同一オリジンのため Audio API が使える）。
 */
(function () {
  'use strict';

  // ── 不可視マーカー（標準リアクションと同じ）────────────────
  const INVISIBLE_REACTION = '\u3164\u3164\u3164';

  /**
   * カスタムリアクション用の HTML メッセージを構築。
   * ovice の Canvas レンダラは <img> タグをサポートしている。
   */
  function buildReactionHtml(name, iconSrc) {
    return '<span for="' + name + '" style="font-size: 1.5rem;">'
         + '<img src="' + iconSrc + '" width="42" height="42" style="vertical-align:middle;" />'
         + '</span>';
  }

  /**
   * 効果音を再生する。
   * ovice の効果音は同一オリジンの /assets/reaction/sound/*.mp3 にある。
   * sound が "no_sound" または空の場合は再生しない。
   */
  /**
   * ovice のオーディオ設定からリアクション音量を取得する。
   * localStorage の deviceSettings.reactionsVolume を参照。
   */
  function getOviceReactionsVolume() {
    try {
      const settings = JSON.parse(localStorage.getItem('deviceSettings') || '{}');
      return settings.reactionsVolume != null ? settings.reactionsVolume : 0.5;
    } catch (e) {
      return 0.5;
    }
  }

  function playSound(sound) {
    if (!sound || sound === 'no_sound') return;
    try {
      const url = sound.startsWith('http') ? sound : window.location.origin + sound;
      const audio = new Audio(url);
      audio.volume = Math.max(0, Math.min(1, getOviceReactionsVolume()));
      audio.play().catch(err => {
        console.warn('[ovice RS] Sound playback failed:', err);
      });
    } catch (err) {
      console.warn('[ovice RS] Sound error:', err);
    }
  }

  // ── AudioBufferSourceNode.start の抑制管理（v1.7.1 重大バグ修正）──────
  // 旧実装はクリック毎に origStart を取り直していたため、連打や例外で
  // 「空関数」が origStart として保存され、復元後も全効果音が消える事故が発生。
  // ovice のチャット通知音・受信リアクション音も同じ Web Audio API を使うため、
  // 一度壊れると ovice のすべての効果音が無音化する。
  // 対策: モジュールトップで一度だけ origStart をキャッシュ + カウンタ方式 + try/finally。
  const ORIG_START = AudioBufferSourceNode.prototype.start;
  const NOOP_START = function () {};
  let suppressCount = 0;

  function suppressStart() {
    if (suppressCount++ === 0) {
      AudioBufferSourceNode.prototype.start = NOOP_START;
    }
  }
  function restoreStart() {
    if (--suppressCount <= 0) {
      suppressCount = 0;
      AudioBufferSourceNode.prototype.start = ORIG_START;
    }
  }

  /**
   * カスタムリアクションを送信する。
   * 標準リアクションと同じメソッド呼び出しフローを再現:
   *   1. ovice 側の効果音を抑制（AudioBufferSourceNode.start を無効化）
   *   2. ovice.react(INVISIBLE) - リアクションバブルを表示
   *   3. ovice.chat(html)       - HTML メッセージを表示 + broadcast
   *   4. ovice.commitReaction() - アナリティクス + キャンセルタイマー
   *   5. 抑制を解除し、ovice の reactionsVolume 設定に従って効果音を再生
   */
  function sendReaction(name, iconSrc, sound) {
    const o = window.ovice;
    if (!o || !o.userId_) {
      console.warn('[ovice RS] ovice object or userId not available');
      return false;
    }

    const html = buildReactionHtml(name, iconSrc);

    // setTimeout で非同期実行：クリックイベントのハンドラ内で
    // 同期的に ovice メソッドを呼ぶと Canvas 描画と競合するため
    setTimeout(() => {
      // ovice は Web Audio API (AudioContext) で効果音を再生するため、
      // AudioBufferSourceNode.prototype.start を一時的に無効化して抑制
      suppressStart();
      try {
        o.react(INVISIBLE_REACTION);
        o.chat(html);
        o.commitReaction();
      } catch (err) {
        console.warn('[ovice RS] Reaction failed:', err);
      } finally {
        // 少し待ってから復元（非同期スケジュール対応）し、拡張機能の音を再生
        // finally で必ず restore タイマーを set し、例外時も復元される
        setTimeout(() => {
          restoreStart();
          playSound(sound);
          console.log('[ovice RS] Reaction sent:', name);
        }, 150);
      }
    }, 50);
    return true;
  }

  // ── content.js からのイベントを受信 ──────────────────────────
  window.addEventListener('__ovice_rs_send_reaction', (e) => {
    const { name, iconSrc, sound } = e.detail || {};
    if (!name || !iconSrc) {
      console.warn('[ovice RS] Invalid reaction data:', e.detail);
      return;
    }
    const ok = sendReaction(name, iconSrc, sound);
    window.dispatchEvent(new CustomEvent('__ovice_rs_send_result', { detail: ok }));
  });

  // ── ovice オブジェクトの準備状態を返す ────────────────────────
  window.addEventListener('__ovice_rs_check_ready', () => {
    const o = window.ovice;
    const ready = !!(o && o.userId_ && typeof o.react === 'function');
    window.dispatchEvent(new CustomEvent('__ovice_rs_ready_result', { detail: ready }));
  });
})();
