/**
 * ovice Reaction Deck - Injected Script (v2.1)
 * ページコンテキストで動作。
 * content.js からカスタムイベント経由でリアクション送信指示を受け取り、
 * window.ovice の内部メソッドを使って Canvas 上にリアクションを表示する。
 * 効果音もこのスクリプトで再生する（同一オリジンのため Audio API が使える）。
 */
(function () {
  'use strict';

  // ── 不可視マーカー（標準リアクションと同じ）────────────────
  const INVISIBLE_REACTION = '\u3164\u3164\u3164';
  const REACTION_IMAGE_DATA_URL_PATTERN = /^data:image\/(png|gif|webp|jpeg);base64,[A-Za-z0-9+/=\x20]*$/;
  const ALLOWED_REACTION_SOUNDS = new Set([
    'no_sound',
    '/assets/reaction/sound/positive.mp3',
    '/assets/reaction/sound/love.mp3',
    '/assets/reaction/sound/haha.mp3',
    '/assets/reaction/sound/negative.mp3',
    '/assets/reaction/sound/negative_nope.mp3',
    '/assets/reaction/sound/surprised.mp3',
    '/assets/reaction/sound/question.mp3',
    '/assets/reaction/sound/sword.mp3',
    '/assets/reaction/sound/wait.mp3',
    '/assets/reaction/sound/clapping.mp3',
    '/assets/reaction/sound/drum.mp3',
    '/assets/reaction/sound/tada.mp3',
  ]);
  const RECEIVER_REACTION_SOUND_KEYS = new Set([
    'no_sound',
    'positive',
    'negative',
    'negative_nope',
    'love',
    'haha',
    'surprised',
    'question',
    'sword',
    'wait',
    'clapping',
    'drum',
    'tada',
  ]);

  /**
   * カスタムリアクション用の HTML メッセージを構築。
   * ovice の Canvas レンダラは <img> タグをサポートしている。
   */
  function sanitizeForOvice(str) {
    // ovice が受信メッセージを indexOf('hi5') で判定してハイタッチ音を鳴らすため、
    // 空白を挿入して回避する（base64 は forgiving-base64 仕様で空白を無視する）。
    return String(str).replace(/hi5/g, 'hi 5');
  }

  function normalizeReactionName(name) {
    return String(name).replace(/[\u0000-\u001F\u007F-\u009F\u2028\u2029]/g, '').substring(0, 20);
  }

  function isValidReactionIconSrc(iconSrc) {
    return REACTION_IMAGE_DATA_URL_PATTERN.test(iconSrc);
  }

  function normalizeReactionSound(sound) {
    if (ALLOWED_REACTION_SOUNDS.has(sound)) return sound;
    console.warn('[ovice RS] Invalid reaction sound; using no_sound:', sound);
    return 'no_sound';
  }

  function getReceiverReactionSoundKey(sound) {
    if (!ALLOWED_REACTION_SOUNDS.has(sound)) return null;
    if (sound === 'no_sound') return 'no_sound';
    const match = /^\/assets\/reaction\/sound\/([^/]+)\.mp3$/.exec(sound);
    if (!match || !RECEIVER_REACTION_SOUND_KEYS.has(match[1])) return null;
    return match[1];
  }

  function buildReactionHtml(name, iconSrc, sound) {
    const safeName = sanitizeForOvice(normalizeReactionName(name));
    const safeIconSrc = sanitizeForOvice(iconSrc);
    const span = document.createElement('span');
    span.setAttribute('for', safeName);
    span.setAttribute('style', 'font-size: 1.5rem;');
    const img = document.createElement('img');
    const hasSpoofedSoundAttribute = String(name).includes('data-custom-icon-name=')
      || String(iconSrc).includes('data-custom-icon-name=');
    const receiverSoundKey = getReceiverReactionSoundKey(sound);
    if (receiverSoundKey && !hasSpoofedSoundAttribute) {
      img.setAttribute('data-custom-icon-name', receiverSoundKey);
    }

    img.setAttribute('src', safeIconSrc);
    img.setAttribute('width', '42');
    img.setAttribute('height', '42');
    img.setAttribute('style', 'vertical-align:middle;');
    span.appendChild(img);

    return span.outerHTML;
  }

  /**
   * 効果音を再生する。
   * ovice の効果音は同一オリジンの /assets/reaction/sound/*.mp3 にある。
   * sound が "no_sound" または空の場合は再生しない。
   */
  /**
   * ovice のオーディオ設定からリアクション音量を取得する。
   * localStorage の deviceSettings.reactionsVolume を参照。
   */
  function getOviceReactionsVolume() {
    try {
      const settings = JSON.parse(localStorage.getItem('deviceSettings') || '{}');
      return settings.reactionsVolume != null ? settings.reactionsVolume : 0.5;
    } catch (e) {
      return 0.5;
    }
  }

  function playSound(sound) {
    if (!sound || sound === 'no_sound') return;
    try {
      const url = sound.startsWith('http') ? sound : window.location.origin + sound;
      const audio = new Audio(url);
      audio.volume = Math.max(0, Math.min(1, getOviceReactionsVolume()));
      audio.play().catch(err => {
        console.warn('[ovice RS] Sound playback failed:', err);
      });
    } catch (err) {
      console.warn('[ovice RS] Sound error:', err);
    }
  }

  // ── AudioBufferSourceNode.start の抑制管理（v1.7.1 重大バグ修正）──────
  // 旧実装はクリック毎に origStart を取り直していたため、連打や例外で
  // 「空関数」が origStart として保存され、復元後も全効果音が消える事故が発生。
  // ovice のチャット通知音・受信リアクション音も同じ Web Audio API を使うため、
  // 一度壊れると ovice のすべての効果音が無音化する。
  // 対策: モジュールトップで一度だけ origStart をキャッシュ + カウンタ方式 + try/finally。
  const ORIG_START = AudioBufferSourceNode.prototype.start;
  const NOOP_START = function () {};
  let suppressCount = 0;

  function suppressStart() {
    if (suppressCount++ === 0) {
      AudioBufferSourceNode.prototype.start = NOOP_START;
    }
  }
  function restoreStart() {
    if (--suppressCount <= 0) {
      suppressCount = 0;
      AudioBufferSourceNode.prototype.start = ORIG_START;
    }
  }

  /**
   * カスタムリアクションを送信する。
   * 標準リアクションと同じメソッド呼び出しフローを再現:
   *   1. ovice 側の効果音を抑制（AudioBufferSourceNode.start を無効化）
   *   2. ovice.react(INVISIBLE) - リアクションバブルを表示
   *   3. ovice.chat(html)       - HTML メッセージを表示 + broadcast
   *   4. ovice.commitReaction() - アナリティクス + キャンセルタイマー
   *   5. 抑制を解除し、ovice の reactionsVolume 設定に従って効果音を再生
   */
  function sendReaction(name, iconSrc, sound, reportResult) {
    const safeIconSrc = sanitizeForOvice(iconSrc);
    if (!isValidReactionIconSrc(safeIconSrc)) {
      console.warn('[ovice RS] Invalid reaction image data URL; send cancelled');
      if (reportResult) reportResult(false, 'invalid-icon');
      return false;
    }
    const safeSound = normalizeReactionSound(sound);
    const html = buildReactionHtml(name, iconSrc, safeSound);

    // setTimeout で非同期実行：クリックイベントのハンドラ内で
    // 同期的に ovice メソッドを呼ぶと Canvas 描画と競合するため
    setTimeout(() => {
      const o = window.ovice;
      if (!o || !o.userId_) {
        console.warn('[ovice RS] ovice object or userId not available');
        if (reportResult) reportResult(false, 'ovice-unavailable');
        return;
      }

      // ovice は Web Audio API (AudioContext) で効果音を再生するため、
      // AudioBufferSourceNode.prototype.start を一時的に無効化して抑制
      suppressStart();
      let ok = false;
      try {
        // ここで検知するのは同期例外まで。返された Promise の完了は待たない。
        o.react(INVISIBLE_REACTION);
        o.chat(html);
        o.commitReaction();
        ok = true;
      } catch (err) {
        console.warn('[ovice RS] Reaction failed:', err);
      } finally {
        // 少し待ってから復元（非同期スケジュール対応）し、拡張機能の音を再生
        // finally で必ず restore タイマーを set し、例外時も復元される
        setTimeout(() => {
          restoreStart();
          if (ok) {
            playSound(safeSound);
            console.log('[ovice RS] Reaction sent:', name);
          }
        }, 150);
      }
      if (reportResult) reportResult(ok, ok ? undefined : 'send-exception');
    }, 50);
    return true;
  }

  // ── content.js からのイベントを受信 ──────────────────────────
  window.addEventListener('__ovice_rs_send_reaction', (e) => {
    const { requestId, name, iconSrc, sound } = e.detail || {};
    const reportResult = (ok, reason) => {
      const detail = { requestId, ok };
      if (reason) detail.reason = reason;
      window.dispatchEvent(new CustomEvent('__ovice_rs_send_result', { detail }));
    };
    if (!requestId || !name || !iconSrc) {
      console.warn('[ovice RS] Invalid reaction data:', e.detail);
      reportResult(false, 'invalid-data');
      return;
    }
    sendReaction(name, iconSrc, sound, reportResult);
  });

  // ── ovice オブジェクトの準備状態を返す ────────────────────────
  window.addEventListener('__ovice_rs_check_ready', () => {
    const o = window.ovice;
    const ready = !!(o && o.userId_ && typeof o.react === 'function');
    window.dispatchEvent(new CustomEvent('__ovice_rs_ready_result', { detail: ready }));
  });
})();
