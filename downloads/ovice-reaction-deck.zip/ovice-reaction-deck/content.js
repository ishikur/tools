/**
 * ovice Reaction Deck - Content Script (v2.1)
 *
 * ovice画面上にフローティングリアクションパネルを表示。
 * 登録済みリアクション画像をクリックすると、injected.js 経由で
 * ovice.react() + ovice.chat() + ovice.commitReaction() を呼び出す。
 * パネル内のリアクション画像はドラッグ&ドロップで位置を入れ替え可能。
 * グリッドには空セルを置ける。リサイズは上下左右＋角の8方向。
 */
(function () {
  'use strict';
  if (document.getElementById('ovice-rs-root')) return;

  const STORAGE_KEY = 'oviceReactions';     // [{ id, name, dataUrl, sound }]
  const GRID_KEY    = 'oviceGridLayout';    // [reactionId | null, ...]
  const SETTINGS_KEY = 'oviceRsSettings';   // { maxCols, maxRows, panelOpacity }
  const REACTION_IMAGE_DATA_URL_PATTERN = /^data:image\/(png|gif|webp|jpeg);base64,[A-Za-z0-9+/=\x20]*$/;
  const ALLOWED_REACTION_SOUNDS = new Set([
    'no_sound',
    '/assets/reaction/sound/positive.mp3',
    '/assets/reaction/sound/love.mp3',
    '/assets/reaction/sound/haha.mp3',
    '/assets/reaction/sound/negative.mp3',
    '/assets/reaction/sound/negative_nope.mp3',
    '/assets/reaction/sound/surprised.mp3',
    '/assets/reaction/sound/question.mp3',
    '/assets/reaction/sound/sword.mp3',
    '/assets/reaction/sound/wait.mp3',
    '/assets/reaction/sound/clapping.mp3',
    '/assets/reaction/sound/drum.mp3',
    '/assets/reaction/sound/tada.mp3',
  ]);

  function isValidReactionDataUrl(dataUrl) {
    return typeof dataUrl === 'string' && REACTION_IMAGE_DATA_URL_PATTERN.test(dataUrl);
  }

  function normalizeReactionSound(sound) {
    return ALLOWED_REACTION_SOUNDS.has(sound) ? sound : 'no_sound';
  }

  let reactions   = [];
  let gridLayout  = {};    // { "row,col": reactionId } — 2D座標ベース
  let panelOpen   = false;
  let panelOpacity = 75;
  let animateGif  = false;
  let panelScale  = 1;
  const newReactionIds = new Set(); // 未使用の新規リアクションID
  const SEND_RESULT_TIMEOUT_MS = 3000;
  let sendRequestSequence = 0;

  // パネル設定
  const ITEM_SIZE = 48;
  const GAP       = 6;
  const PAD       = 10;
  const PANEL_CHROME_H_FALLBACK = 36;
  const PANEL_GAP = 8;
  const MIN_COLS  = 3;
  let   MAX_COLS  = 10;
  const MIN_ROWS  = 2;
  let   MAX_ROWS  = 10;
  // パネルサイズは常に MAX_COLS × MAX_ROWS（設定値）を使用
  // panelCorner: トグルボタンがパネルのどの位置にあるか
  // 'top-left','top-right','bottom-left','bottom-right' → ボタンがパネルの上/下
  // 'left-top','left-bottom','right-top','right-bottom'  → ボタンがパネルの左/右
  let panelCorner = 'bottom-right';
  let buttonMovedWhileClosed = false; // 閉じた状態でボタンが移動されたか
  // トグルボタンの保存位置: { anchor: 'left-top'|'left-bottom'|'right-top'|'right-bottom', offsetX, offsetY }
  // null の場合は CSS デフォルト（right:18, bottom:90）
  let togglePos = null;

  // ── injected.js をページコンテキストに注入 ────────────────────
  function injectScript() {
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL('injected.js');
    (document.head || document.documentElement).appendChild(script);
    script.onload = () => script.remove();
  }
  injectScript();

  // ── リアクションパネルを自動で開く ────────────────────────
  (function autoOpenReactionPanel() {
    const MENU_SELECTOR = '[data-testid="reactions-menu"]';
    const NATIVE_REACTION_SELECTOR =
      'button[data-testid^="reactions-"]:not([data-testid="reactions-menu"])';
    const SETTLE_MS = 500;
    const TIMEOUT_MS = 60000;
    let currentUrl = location.href;
    let generation = 1;
    let clickScheduled = false;
    let generationComplete = false;
    let transitionCarryover = [];

    function isVisible(el) {
      if (!el || el.hidden) return false;
      const rect = el.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    }

    function visibleNativeReactions() {
      return Array.from(document.querySelectorAll(NATIVE_REACTION_SELECTOR)).filter(isVisible);
    }

    function isPanelOpen() {
      return visibleNativeReactions().length > 0;
    }

    function finishGeneration(token) {
      if (token !== generation) return;
      generationComplete = true;
      clickScheduled = false;
    }

    function startGeneration(nextUrl) {
      currentUrl = nextUrl;
      generation += 1;
      clickScheduled = false;
      generationComplete = false;
      // URL変更を検出した時点で見えている標準パネルは移動元の残像かもしれない。
      // 同じ要素が消えるまでは、移動先パネルが復元済みとは判定しない。
      transitionCarryover = visibleNativeReactions();
      const token = generation;
      setTimeout(() => finishGeneration(token), TIMEOUT_MS);
    }

    function tryEnsureOpen() {
      if (location.href !== currentUrl) startGeneration(location.href);
      if (generationComplete) return;

      if (transitionCarryover.length > 0) {
        transitionCarryover = transitionCarryover.filter(isVisible);
        if (transitionCarryover.length > 0) return;
      }

      if (isPanelOpen()) {
        finishGeneration(generation);
        return;
      }

      const btn = document.querySelector(MENU_SELECTOR);
      if (!isVisible(btn) || btn.disabled || clickScheduled) return;

      // 現行 ovice ではパネルが開いていても menu の data-state は closed のまま。
      // URL 遷移中の復元パネルを閉じないよう少し待ち、そのURL世代でまだ閉じている場合だけ1回押す。
      clickScheduled = true;
      const token = generation;
      const scheduledUrl = currentUrl;
      setTimeout(() => {
        if (token !== generation || scheduledUrl !== location.href) return;
        if (generationComplete || isPanelOpen()) {
          finishGeneration(token);
          return;
        }
        const currentBtn = document.querySelector(MENU_SELECTOR);
        if (!isVisible(currentBtn) || currentBtn.disabled) {
          clickScheduled = false;
          return;
        }
        generationComplete = true;
        clickScheduled = false;
        currentBtn.click();
      }, SETTLE_MS);
    }

    // capture phaseで本人の標準メニューボタン操作を実証的に拾う。
    // DOM消失だけでは遷移とmanual closeを区別できないため、trusted clickだけを採用する。
    document.addEventListener('click', event => {
      if (event.isTrusted !== true) return;
      const menu = document.querySelector(MENU_SELECTOR);
      if (!menu) return;
      const target = event.target;
      if (target !== menu && !menu.contains(target)) return;
      if (location.href !== currentUrl) startGeneration(location.href);
      finishGeneration(generation);
    }, true);

    const observer = new MutationObserver(tryEnsureOpen);
    observer.observe(document.body, { childList: true, subtree: true });
    tryEnsureOpen();
    const initialToken = generation;
    setTimeout(() => finishGeneration(initialToken), TIMEOUT_MS);
  })();

  // ── 「ブラウザでの利用を継続」を自動クリック ───────────────
  (function autoDismissAppModal() {
    const TARGET_TEXT = 'ブラウザでの利用を継続';
    function tryClick() {
      for (const el of document.querySelectorAll('button, a, [role="button"]')) {
        if (el.textContent.trim() === TARGET_TEXT) { el.click(); return true; }
      }
      return false;
    }
    if (!tryClick()) {
      const obs = new MutationObserver(() => { if (tryClick()) obs.disconnect(); });
      obs.observe(document.body, { childList: true, subtree: true });
      setTimeout(() => obs.disconnect(), 10000);
    }
  })();

  // ── ヘルパー ──────────────────────────────────────────────────
  function getReactionById(id) {
    return reactions.find(r => r.id === id) || null;
  }

  function calcWidth(cols)      { return PAD * 2 + cols * ITEM_SIZE + (cols - 1) * GAP; }
  function calcGridHeight(rows) { return rows * ITEM_SIZE + (rows - 1) * GAP; }

  // ── panelCorner ヘルパー ──────────────────────────────────────
  /** panelCorner から transform-origin を導出 */
  function cornerToOrigin(corner) {
    const map = {
      'top-left': 'top left',     'top-right': 'top right',
      'bottom-left': 'bottom left', 'bottom-right': 'bottom right',
      'left-top': 'top left',     'left-bottom': 'bottom left',
      'right-top': 'top right',   'right-bottom': 'bottom right',
    };
    return map[corner] || 'bottom right';
  }

  /** ボタンがパネルの上/下/左/右のどの辺にあるか */
  function cornerEdge(corner) {
    return corner.split('-')[0]; // 'top','bottom','left','right'
  }

  /** ボタンがパネルの辺のどちら寄りか */
  function cornerAlign(corner) {
    return corner.split('-')[1]; // 'left','right','top','bottom'
  }

  /** 8箇所のスナップ候補のボタン中心座標を返す */
  function getSnapCandidates(panelRect, btnW, btnH) {
    const g = PANEL_GAP;
    return {
      'top-left':     { x: panelRect.left,  y: panelRect.top - g - btnH / 2 },
      'top-right':    { x: panelRect.right - btnW, y: panelRect.top - g - btnH / 2 },
      'bottom-left':  { x: panelRect.left,  y: panelRect.bottom + g + btnH / 2 },
      'bottom-right': { x: panelRect.right - btnW, y: panelRect.bottom + g + btnH / 2 },
      'left-top':     { x: panelRect.left - g - btnW / 2, y: panelRect.top },
      'left-bottom':  { x: panelRect.left - g - btnW / 2, y: panelRect.bottom - btnH },
      'right-top':    { x: panelRect.right + g + btnW / 2, y: panelRect.top },
      'right-bottom': { x: panelRect.right + g + btnW / 2, y: panelRect.bottom - btnH },
    };
  }

  /** ドロップ位置から最も近いスナップ位置を返す */
  function computeNearestSnap(panelRect, bx, by, btnW, btnH) {
    const candidates = getSnapCandidates(panelRect, btnW, btnH);
    let best = panelCorner, bestDist = Infinity;
    for (const [name, pos] of Object.entries(candidates)) {
      const dist = Math.hypot(bx - pos.x, by - pos.y);
      if (dist < bestDist) { bestDist = dist; best = name; }
    }
    return best;
  }

  /** panelCorner からトグルボタンの位置を計算 */
  function getTogglePositionForCorner(corner, panelRect, btnW, btnH) {
    const g = PANEL_GAP;
    const edge = cornerEdge(corner);
    const align = cornerAlign(corner);
    let x, y;
    if (edge === 'top') {
      y = panelRect.top - g - btnH;
      x = align === 'left' ? panelRect.left : panelRect.right - btnW;
    } else if (edge === 'bottom') {
      y = panelRect.bottom + g;
      x = align === 'left' ? panelRect.left : panelRect.right - btnW;
    } else if (edge === 'left') {
      x = panelRect.left - g - btnW;
      y = align === 'top' ? panelRect.top : panelRect.bottom - btnH;
    } else { // right
      x = panelRect.right + g;
      y = align === 'top' ? panelRect.top : panelRect.bottom - btnH;
    }
    return { x, y };
  }

  /** 指定コーナーでパネルがビューポートに収まるか */
  function fitsInViewport(corner, tRect, panelW, panelH, vw, vh) {
    const edge = cornerEdge(corner);
    const margin = 8;
    if (edge === 'top')    return tRect.bottom + PANEL_GAP + panelH <= vh - margin;
    if (edge === 'bottom') return tRect.top - PANEL_GAP - panelH >= margin;
    if (edge === 'left')   return tRect.right + PANEL_GAP + panelW <= vw - margin;
    if (edge === 'right')  return tRect.left - PANEL_GAP - panelW >= margin;
    return false;
  }

  /** ボタン位置から最適なコーナーを自動選択 */
  function bestCornerForPosition(tRect, vw, vh) {
    const cx = tRect.left + tRect.width / 2;
    const cy = tRect.top + tRect.height / 2;
    // 上下: ボタンが上半分→パネル下(top-*)、下半分→パネル上(bottom-*)
    const vert = cy < vh / 2 ? 'top' : 'bottom';
    // 左右: ボタンが左半分→右寄せ(right)、右半分→左寄せ(left) — ここはalign
    const horiz = cx < vw / 2 ? 'left' : 'right';
    return vert + '-' + horiz;
  }

  /** panelCorner の反対側を返す（スペース不足時のフォールバック） */
  function flipCorner(corner) {
    const map = {
      'top-left': 'bottom-left',  'top-right': 'bottom-right',
      'bottom-left': 'top-left',  'bottom-right': 'top-right',
      'left-top': 'right-top',    'left-bottom': 'right-bottom',
      'right-top': 'left-top',    'right-bottom': 'left-bottom',
    };
    return map[corner] || corner;
  }

  /**
   * パネルがビューポートに収まるようトグルボタン位置を補正する。
   * ドラッグ終了時に呼ばれ、スムーズにスナップバックする。
   */
  function snapToggleToFit(animate = true) {
    const root   = document.getElementById('ovice-rs-root');
    const toggle = document.getElementById('ovice-rs-toggle');
    const panel  = document.getElementById('ovice-rs-panel');
    if (!root || !toggle || !panel) return;

    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const margin = 8;
    const tRect = toggle.getBoundingClientRect();
    const tw = toggle.offsetWidth;
    const th = toggle.offsetHeight;
    const edge = cornerEdge(panelCorner);

    // パネルのスケール済み寸法
    const panelW = panel.offsetWidth * panelScale;
    const panelH = panel.offsetHeight * panelScale;

    // パネルの本来の端座標をトグル位置から計算
    let panelLeft, panelRight, panelTop, panelBottom;
    if (edge === 'top') {
      panelTop    = tRect.bottom + PANEL_GAP;
      panelBottom = panelTop + panelH;
    } else if (edge === 'bottom') {
      panelBottom = tRect.top - PANEL_GAP;
      panelTop    = panelBottom - panelH;
    } else if (edge === 'left') {
      panelLeft  = tRect.right + PANEL_GAP;
      panelRight = panelLeft + panelW;
    } else { // right
      panelRight = tRect.left - PANEL_GAP;
      panelLeft  = panelRight - panelW;
    }

    const align = cornerAlign(panelCorner);
    if (edge === 'top' || edge === 'bottom') {
      if (align === 'left') {
        panelLeft  = tRect.left;
        panelRight = panelLeft + panelW;
      } else {
        panelRight = tRect.right;
        panelLeft  = panelRight - panelW;
      }
    } else {
      if (align === 'top') {
        panelTop    = tRect.top;
        panelBottom = panelTop + panelH;
      } else {
        panelBottom = tRect.bottom;
        panelTop    = panelBottom - panelH;
      }
    }

    let nx = tRect.left;
    let ny = tRect.top;

    // はみ出し分だけトグルを補正
    if (panelLeft < margin)        nx += (margin - panelLeft);
    if (panelRight > vw - margin)  nx -= (panelRight - (vw - margin));
    if (panelTop < margin)         ny += (margin - panelTop);
    if (panelBottom > vh - margin) ny -= (panelBottom - (vh - margin));

    // トグル自体もビューポート内に
    nx = Math.max(0, Math.min(vw - tw, nx));
    ny = Math.max(0, Math.min(vh - th, ny));

    // 位置が変わらない場合は何もしない（ズレ防止）
    if (Math.abs(nx - tRect.left) < 0.5 && Math.abs(ny - tRect.top) < 0.5) return;

    root.style.right = 'auto';
    root.style.bottom = 'auto';
    if (animate) {
      root.style.transition = 'left 0.2s ease, top 0.2s ease';
      root.style.left = nx + 'px';
      root.style.top = ny + 'px';
      setTimeout(() => { root.style.transition = ''; }, 220);
    } else {
      root.style.transition = '';
      root.style.left = nx + 'px';
      root.style.top = ny + 'px';
    }
  }

  // ── gridLayout ヘルパー（2D座標ベース）─────────────────────────
  function gridKey(row, col) { return row + ',' + col; }

  /** gridLayout を reactions に同期。削除分は除去、新規は空きセルに追加 */
  function syncGridLayout() {
    const reactionIds = new Set(reactions.map(r => r.id));
    const inLayout = new Set();

    // 削除されたリアクションを除去
    for (const key of Object.keys(gridLayout)) {
      if (!reactionIds.has(gridLayout[key])) {
        delete gridLayout[key];
      } else {
        inLayout.add(gridLayout[key]);
      }
    }

    // 新規リアクションを空きセルに追加
    reactions.forEach(r => {
      if (!inLayout.has(r.id)) {
        const pos = findEmptyCell();
        if (pos) gridLayout[gridKey(pos.row, pos.col)] = r.id;
        newReactionIds.add(r.id);
      }
    });
  }

  /** グリッド内の最初の空きセルを探す */
  function findEmptyCell() {
    for (let row = 0; row < MAX_ROWS; row++) {
      for (let col = 0; col < MAX_COLS; col++) {
        if (!gridLayout[gridKey(row, col)]) return { row, col };
      }
    }
    return null;
  }

  /** リアクションが配置されている最大行・列を返す */
  function getMaxOccupied() {
    let maxRow = 0, maxCol = 0;
    for (const key of Object.keys(gridLayout)) {
      const [r, c] = key.split(',').map(Number);
      maxRow = Math.max(maxRow, r);
      maxCol = Math.max(maxCol, c);
    }
    return { maxRow, maxCol };
  }

  function reportStorageSaveError(error) {
    console.warn('[ovice RS] Storage save failed:', error?.message || error);
  }

  let panelToastTimer;
  function showPanelToast(message) {
    let toast = document.getElementById('ovice-rs-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'ovice-rs-toast';
      toast.style.cssText = 'position:fixed;left:50%;bottom:24px;transform:translateX(-50%);z-index:2147483647;padding:10px 16px;border-radius:8px;background:#ef4444;color:#fff;font-size:13px;box-shadow:0 4px 12px rgba(0,0,0,.25);';
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    clearTimeout(panelToastTimer);
    panelToastTimer = setTimeout(() => toast.remove(), 2200);
  }

  function reloadDeckFromStorage() {
    chrome.storage.local.get([STORAGE_KEY, GRID_KEY], (result) => {
      reactions = result[STORAGE_KEY] || [];
      const savedGrid = result[GRID_KEY];
      if (Array.isArray(savedGrid)) {
        gridLayout = {};
        const oldCols = 10;
        savedGrid.forEach((id, idx) => {
          if (id != null) gridLayout[gridKey(Math.floor(idx / oldCols), idx % oldCols)] = id;
        });
      } else {
        gridLayout = savedGrid || {};
      }
      for (const id of newReactionIds) {
        if (!reactions.some(reaction => reaction.id === id)) newReactionIds.delete(id);
      }
      renderGrid();
    });
  }

  function setLocal(values, onSuccess, rollbackDeck = false) {
    chrome.storage.local.set(values, () => {
      const error = chrome.runtime.lastError;
      if (error) {
        reportStorageSaveError(error);
        if (rollbackDeck) reloadDeckFromStorage();
        return;
      }
      if (onSuccess) onSuccess();
    });
  }

  function saveGridLayout(cb) {
    setLocal({ [GRID_KEY]: gridLayout }, cb, true);
  }

  // ── 初期化 ────────────────────────────────────────────────────
  chrome.storage.local.get([STORAGE_KEY, GRID_KEY, SETTINGS_KEY], (result) => {
    reactions = result[STORAGE_KEY] || [];
    const savedGrid = result[GRID_KEY];

    // 旧フォーマット（配列）からの移行
    if (Array.isArray(savedGrid)) {
      gridLayout = {};
      const oldCols = 10; // 旧デフォルト列数
      savedGrid.forEach((id, idx) => {
        if (id != null) {
          const row = Math.floor(idx / oldCols);
          const col = idx % oldCols;
          gridLayout[gridKey(row, col)] = id;
        }
      });
      // 移行後の新フォーマットを保存
      setLocal({ [GRID_KEY]: gridLayout }, null, true);
    } else {
      gridLayout = savedGrid || {};
    }

    const settings = result[SETTINGS_KEY] || {};
    panelOpacity = settings.panelOpacity != null ? settings.panelOpacity : 75;
    animateGif = !!settings.animateGif;
    panelScale = settings.panelScale != null ? settings.panelScale : 1;
    if (settings.panelCorner) panelCorner = settings.panelCorner;
    if (settings.togglePos) togglePos = settings.togglePos;
    if (settings.maxCols) MAX_COLS = Math.max(MIN_COLS, settings.maxCols);
    if (settings.maxRows) MAX_ROWS = Math.max(MIN_ROWS, settings.maxRows);

    syncGridLayout();
    buildUI();
  });

  // ストレージの変更を監視（popup から追加/削除された場合）
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;

    // GRID_KEY が同時に変更された場合（インポート）はそちらを優先
    if (changes[GRID_KEY]) {
      const newGrid = changes[GRID_KEY].newValue;
      if (newGrid && typeof newGrid === 'object' && !Array.isArray(newGrid)) {
        gridLayout = newGrid;
      }
    }

    if (changes[STORAGE_KEY]) {
      reactions = changes[STORAGE_KEY].newValue || [];
      syncGridLayout();
      if (!changes[GRID_KEY]) {
        // グリッドが同時に変更されていない場合のみ保存
        saveGridLayout(() => renderGrid());
      } else {
        renderGrid();
      }
    }

    if (changes[SETTINGS_KEY]) {
      const s = changes[SETTINGS_KEY].newValue || {};
      const oldCols = MAX_COLS, oldRows = MAX_ROWS;
      const oldOpacity = panelOpacity, oldScale = panelScale, oldAnimate = animateGif;
      const oldTogglePosJson = JSON.stringify(togglePos);
      panelOpacity = s.panelOpacity != null ? s.panelOpacity : 75;
      animateGif = !!s.animateGif;
      panelScale = s.panelScale != null ? s.panelScale : 1;
      if (s.panelCorner) panelCorner = s.panelCorner;
      togglePos = s.togglePos || null;
      if (s.maxCols) MAX_COLS = Math.max(MIN_COLS, s.maxCols);
      if (s.maxRows) MAX_ROWS = Math.max(MIN_ROWS, s.maxRows);
      // togglePos の変更（リセット含む）を反映: パネル閉のみ
      if (JSON.stringify(togglePos) !== oldTogglePosJson && !panelOpen) {
        applyTogglePos();
        buttonMovedWhileClosed = true;
      }
      // panelCorner だけの変更ではパネル再配置しない（スナップアニメーション中の二重移動防止）
      const needResize = oldCols !== MAX_COLS || oldRows !== MAX_ROWS
        || oldScale !== panelScale || oldOpacity !== panelOpacity;
      if (needResize) {
        applyPanelOpacity();
        if (panelOpen) applyPanelSize();
      }
      const shouldRenderGrid = oldAnimate !== animateGif
        || oldCols !== MAX_COLS || oldRows !== MAX_ROWS;
      const gridExpanded = MAX_COLS > oldCols || MAX_ROWS > oldRows;
      if (gridExpanded) {
        const gridLayoutBeforeSync = JSON.stringify(gridLayout);
        syncGridLayout();
        if (JSON.stringify(gridLayout) !== gridLayoutBeforeSync) {
          saveGridLayout(() => renderGrid());
        } else if (shouldRenderGrid) {
          renderGrid();
        }
      } else if (shouldRenderGrid) {
        renderGrid();
      }
    }
  });

  // ── トグルアイコン ──────────────────────────────────────────────
  const ICON_SMILE = `<svg width="22" height="22" viewBox="0 0 24 24" fill="none"
    stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <circle cx="12" cy="12" r="10"/>
    <path d="M8 14s1.5 2 4 2 4-2 4-2"/>
    <line x1="9" y1="9" x2="9.01" y2="9"/>
    <line x1="15" y1="9" x2="15.01" y2="9"/>
  </svg>`;
  const ICON_CLOSE = `<svg width="22" height="22" viewBox="0 0 24 24" fill="none"
    stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <line x1="18" y1="6" x2="6" y2="18"/>
    <line x1="6" y1="6" x2="18" y2="18"/>
  </svg>`;

  // ── UI構築 ────────────────────────────────────────────────────
  function buildUI() {
    const root = document.createElement('div');
    root.id = 'ovice-rs-root';

    // トグルボタン
    const toggle = document.createElement('button');
    toggle.id = 'ovice-rs-toggle';
    toggle.title = 'リアクションパネル';
    toggle.innerHTML = ICON_SMILE;

    // ドラッグ移動
    const DRAG_THRESHOLD = 5;
    let wasDragging = false;

    function attachToggleDrag() {
      let sx = 0, sy = 0, rx = 0, ry = 0, dragging = false;
      toggle.addEventListener('mousedown', (e) => {
        if (e.button !== 0) return;
        dragging = false;
        sx = e.clientX; sy = e.clientY;
        const rect = root.getBoundingClientRect();
        rx = rect.left; ry = rect.top;
        root.style.right = 'auto'; root.style.bottom = 'auto';
        root.style.left = rx + 'px'; root.style.top = ry + 'px';

        function onMove(ev) {
          const dx = ev.clientX - sx, dy = ev.clientY - sy;
          if (!dragging && Math.hypot(dx, dy) > DRAG_THRESHOLD) {
            dragging = true; wasDragging = true;
            toggle.classList.add('ovice-rs-toggle--dragging');
          }
          if (!dragging) return;
          const nx = Math.max(0, Math.min(window.innerWidth - root.offsetWidth, rx + dx));
          const ny = Math.max(0, Math.min(window.innerHeight - root.offsetHeight, ry + dy));
          root.style.left = nx + 'px'; root.style.top = ny + 'px';
          // パネル閉じてる時だけパネルも追従
          if (panelOpen) {
            // パネルは動かさない（ボタンだけ移動）
          }
        }
        function onUp() {
          document.removeEventListener('mousemove', onMove);
          document.removeEventListener('mouseup', onUp);
          toggle.classList.remove('ovice-rs-toggle--dragging');
          if (panelOpen && dragging) {
            // パネルのBoundingRectからボタンの最寄りスナップ位置を計算
            const panelEl = document.getElementById('ovice-rs-panel');
            if (panelEl) {
              const panelRect = panelEl.getBoundingClientRect();
              const tRect = toggle.getBoundingClientRect();
              const btnW = toggle.offsetWidth;
              const btnH = toggle.offsetHeight;
              panelCorner = computeNearestSnap(panelRect, tRect.left, tRect.top, btnW, btnH);
              // スナップ位置にアニメーション移動
              const snapPos = getTogglePositionForCorner(panelCorner, panelRect, btnW, btnH);
              root.style.transition = 'left 0.15s ease, top 0.15s ease';
              root.style.left = Math.max(0, snapPos.x) + 'px';
              root.style.top = Math.max(0, snapPos.y) + 'px';
              setTimeout(() => {
                root.style.transition = '';
                applyPanelSize();
              }, 170);
              savePanelCorner();
              // スナップアニメーション完了後に位置を保存
              setTimeout(saveTogglePos, 180);
            }
          } else if (!panelOpen && dragging) {
            buttonMovedWhileClosed = true;
            saveTogglePos();
          }
          dragging = false;
        }
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
      });
    }
    attachToggleDrag();

    toggle.addEventListener('click', (e) => {
      if (wasDragging) { wasDragging = false; return; }
      e.stopPropagation();
      togglePanel();
    });

    // パネル本体
    const panel = document.createElement('div');
    panel.id = 'ovice-rs-panel';

    // パネル内部コンテンツ（リサイズハンドルの外）
    const panelInner = document.createElement('div');
    panelInner.style.cssText = 'display:flex;flex-direction:column;overflow:hidden;border-radius:14px;height:100%;min-height:0;';
    panelInner.innerHTML = `
      <div class="ovice-rs-header" id="ovice-rs-header">
        <span>リアクション</span>
      </div>
      <div class="ovice-rs-grid" id="ovice-rs-grid"></div>
      <div class="ovice-rs-empty" id="ovice-rs-empty">
        拡張機能アイコンから<br>リアクション画像を追加してください
      </div>
    `;
    panel.appendChild(panelInner);

    // ── スケールリサイズハンドル（四隅）─────────────────────────────
    ['top-left', 'top-right', 'bottom-left', 'bottom-right'].forEach(pos => {
      const handle = document.createElement('div');
      handle.className = 'ovice-rs-scale-handle ovice-rs-scale-handle--' + pos;
      handle.dataset.corner = pos;
      panel.appendChild(handle);
    });

    root.appendChild(panel);
    root.appendChild(toggle);
    document.body.appendChild(root);

    // 保存済みの位置を復元（閉じた状態でボタンが移動された扱いにして
    // 次のパネル展開で最適コーナーを再判定させる）
    if (togglePos) {
      applyTogglePos();
      buttonMovedWhileClosed = true;
    }

    // ヘッダードラッグ → パネルとボタンを一緒に移動
    (function attachHeaderDrag() {
      const header = panel.querySelector('.ovice-rs-header');
      let sx = 0, sy = 0, rx = 0, ry = 0, dragging = false;
      header.addEventListener('mousedown', (e) => {
        if (e.button !== 0) return;
        dragging = false;
        sx = e.clientX; sy = e.clientY;
        const rect = root.getBoundingClientRect();
        rx = rect.left; ry = rect.top;
        root.style.right = 'auto'; root.style.bottom = 'auto';
        root.style.left = rx + 'px'; root.style.top = ry + 'px';

        function onMove(ev) {
          const dx = ev.clientX - sx, dy = ev.clientY - sy;
          if (!dragging && Math.hypot(dx, dy) > DRAG_THRESHOLD) {
            dragging = true;
          }
          if (!dragging) return;
          const nx = Math.max(0, Math.min(window.innerWidth - root.offsetWidth, rx + dx));
          const ny = Math.max(0, Math.min(window.innerHeight - root.offsetHeight, ry + dy));
          root.style.left = nx + 'px'; root.style.top = ny + 'px';
          if (panelOpen) applyPanelSize();
        }
        function onUp() {
          document.removeEventListener('mousemove', onMove);
          document.removeEventListener('mouseup', onUp);
          if (panelOpen) {
            snapToggleToFit();
            applyPanelSize();
          }
          if (dragging) saveTogglePos();
          dragging = false;
        }
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
      });
    })();

    // ── パネルへのファイルドロップ（画像追加）──────────────────────
    setupPanelFileDrop(panel);

    // ── 右クリックメニュー（capture で ovice より先に捕まえる）───────
    root.addEventListener('contextmenu', (e) => {
      const item = e.target.closest('.ovice-rs-item');
      if (!item) return;
      e.preventDefault();
      e.stopPropagation();
      const key = item.dataset.key;
      const id = gridLayout[key];
      const r = id ? getReactionById(id) : null;
      if (r) showDeleteMenu(e.clientX, e.clientY, r, key);
    }, true);

    // ── スケールドラッグ（四隅共通・対角固定）──────────────────────
    panel.querySelectorAll('.ovice-rs-scale-handle').forEach(handle => {
      handle.addEventListener('mousedown', (e) => {
        e.preventDefault();
        e.stopPropagation();

        const corner = handle.dataset.corner;
        const dirX = corner.includes('right') ? 1 : -1;
        const dirY = corner.includes('bottom') ? 1 : -1;
        const startX = e.clientX;
        const startY = e.clientY;
        const startScale = panelScale;

        const rect = panel.getBoundingClientRect();
        const baseDiag = Math.sqrt(rect.width * rect.width + rect.height * rect.height);

        // 対角（固定する角）のビューポート座標
        const anchorVX = corner.includes('right') ? rect.left : rect.right;
        const anchorVY = corner.includes('bottom') ? rect.top : rect.bottom;

        // パネルの非スケール寸法
        const unscaledW = rect.width / startScale;
        const unscaledH = rect.height / startScale;

        // transform-origin を対角に設定し、CSS位置をその角に合わせる
        const originX = corner.includes('right') ? 'left' : 'right';
        const originY = corner.includes('bottom') ? 'top' : 'bottom';
        panel.style.transformOrigin = originY + ' ' + originX;

        if (originX === 'left') {
          panel.style.left = anchorVX + 'px';
          panel.style.right = 'auto';
        } else {
          panel.style.right = (window.innerWidth - anchorVX) + 'px';
          panel.style.left = 'auto';
        }
        if (originY === 'top') {
          panel.style.top = anchorVY + 'px';
          panel.style.bottom = 'auto';
        } else {
          panel.style.bottom = (window.innerHeight - anchorVY) + 'px';
          panel.style.top = 'auto';
        }

        function onMove(ev) {
          ev.stopPropagation();
          const dx = (ev.clientX - startX) * dirX;
          const dy = (ev.clientY - startY) * dirY;
          const diag = (dx + dy) / 2;
          const newScale = Math.max(0.5, Math.min(2, startScale + diag / baseDiag));
          panelScale = Math.round(newScale * 100) / 100;
          panel.style.transform = `scale(${panelScale})`;
        }
        function onUp() {
          document.removeEventListener('mousemove', onMove);
          document.removeEventListener('mouseup', onUp);

          // パネルの現在位置からトグルボタンの位置を逆算して移動
          const panelRect = panel.getBoundingClientRect();
          const toggleEl = document.getElementById('ovice-rs-toggle');
          const rootEl = document.getElementById('ovice-rs-root');
          if (toggleEl && rootEl) {
            const btnW = toggleEl.offsetWidth;
            const btnH = toggleEl.offsetHeight;
            const snapPos = getTogglePositionForCorner(panelCorner, panelRect, btnW, btnH);
            rootEl.style.left = Math.max(0, snapPos.x) + 'px';
            rootEl.style.top = Math.max(0, snapPos.y) + 'px';
            rootEl.style.right = 'auto';
            rootEl.style.bottom = 'auto';
          }

          // デフォルトの位置配置・origin に戻す
          applyPanelSize();
          chrome.storage.local.get([SETTINGS_KEY], (r) => {
            const s = r[SETTINGS_KEY] || {};
            s.panelScale = panelScale;
            setLocal({ [SETTINGS_KEY]: s });
          });
        }
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
      });
    });

    applyPanelSize();
    renderGrid();
  }

  // ── パネルサイズ適用 ─────────────────────────────────────────

  /**
   * パネルのサイズと位置を適用（position: fixed ベース）。
   * トグルボタンの viewport 座標を基準に配置し、
   * ビューポート端からはみ出さないようクランプする。
   */
  function applyPanelScale() {
    const panel = document.getElementById('ovice-rs-panel');
    if (panel) {
      panel.style.transform = `scale(${panelScale})`;
      panel.style.transformOrigin = cornerToOrigin(panelCorner);
    }
  }

  function savePanelCorner() {
    chrome.storage.local.get([SETTINGS_KEY], (r) => {
      const s = r[SETTINGS_KEY] || {};
      s.panelCorner = panelCorner;
      setLocal({ [SETTINGS_KEY]: s });
    });
  }

  // ── トグル位置の保存/復元 ──────────────────────────────────────
  /** 現在の left/top から 最寄りの隅を anchor にした相対座標を計算 */
  function computeTogglePos(x, y, btnW, btnH) {
    const vw = window.innerWidth, vh = window.innerHeight;
    const leftDist = x;
    const rightDist = Math.max(0, vw - (x + btnW));
    const topDist = y;
    const bottomDist = Math.max(0, vh - (y + btnH));
    const horiz = leftDist <= rightDist ? 'left' : 'right';
    const vert  = topDist  <= bottomDist ? 'top'  : 'bottom';
    return {
      anchor: horiz + '-' + vert,
      offsetX: horiz === 'left' ? Math.round(leftDist) : Math.round(rightDist),
      offsetY: vert  === 'top'  ? Math.round(topDist)  : Math.round(bottomDist),
    };
  }

  /** togglePos を root に適用（ビューポート外にはみ出さないようクランプ） */
  function applyTogglePos() {
    const root = document.getElementById('ovice-rs-root');
    if (!root) return;
    if (!togglePos) {
      // デフォルト（右下）
      root.style.left = 'auto';
      root.style.top = 'auto';
      root.style.right = '18px';
      root.style.bottom = '90px';
      return;
    }
    const vw = window.innerWidth, vh = window.innerHeight;
    const btnW = root.offsetWidth || 48;
    const btnH = root.offsetHeight || 48;
    let x = togglePos.anchor.startsWith('left')
      ? togglePos.offsetX
      : vw - btnW - togglePos.offsetX;
    let y = togglePos.anchor.endsWith('top')
      ? togglePos.offsetY
      : vh - btnH - togglePos.offsetY;
    x = Math.max(0, Math.min(vw - btnW, x));
    y = Math.max(0, Math.min(vh - btnH, y));
    root.style.right = 'auto';
    root.style.bottom = 'auto';
    root.style.left = x + 'px';
    root.style.top = y + 'px';
  }

  /** 現在のトグル位置をストレージに保存 */
  function saveTogglePos() {
    const root = document.getElementById('ovice-rs-root');
    if (!root) return;
    const rect = root.getBoundingClientRect();
    togglePos = computeTogglePos(rect.left, rect.top, rect.width, rect.height);
    chrome.storage.local.get([SETTINGS_KEY], (r) => {
      const s = r[SETTINGS_KEY] || {};
      s.togglePos = togglePos;
      setLocal({ [SETTINGS_KEY]: s });
    });
  }

  function applyPanelOpacity() {
    const panel = document.getElementById('ovice-rs-panel');
    if (panel) {
      const alpha = panelOpacity / 100;
      panel.style.background = `rgba(20, 20, 28, ${alpha})`;
      panel.style.backdropFilter = 'none';
      panel.style.webkitBackdropFilter = 'none';
    }
  }

  function applyPanelSize() {
    const panel  = document.getElementById('ovice-rs-panel');
    const toggle = document.getElementById('ovice-rs-toggle');
    if (!panel || !toggle) return;

    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const margin = 8;

    const header = panel.querySelector('.ovice-rs-header');
    const chromeH = header ? header.offsetHeight : PANEL_CHROME_H_FALLBACK;

    const cols = MAX_COLS;
    const rows = MAX_ROWS;
    const panelW = calcWidth(cols);
    const panelH = chromeH + calcGridHeight(rows) + PAD * 2;

    const maxW = vw - margin * 2;
    const maxH = vh - margin * 2;
    const finalW = Math.min(panelW, maxW);
    const finalH = Math.min(panelH, maxH);
    const scaledW = finalW * panelScale;
    const scaledH = finalH * panelScale;

    const tRect = toggle.getBoundingClientRect();
    const edge = cornerEdge(panelCorner);
    const align = cornerAlign(panelCorner);

    // ── サイズ設定 ───────────────────────────────────────────────
    panel.style.width    = finalW + 'px';
    panel.style.height   = finalH + 'px';
    panel.style.overflow = 'hidden';

    const panelInner = panel.firstElementChild;
    if (panelInner) {
      panelInner.style.width    = (finalW - 2) + 'px';
      panelInner.style.height   = (finalH - 2) + 'px';
      panelInner.style.overflow = 'hidden';
    }

    // ── 水平位置 ─────────────────────────────────────────────────
    if (edge === 'top' || edge === 'bottom') {
      // ボタンが上/下辺 → 水平はボタンの左/右端に揃える
      if (align === 'left') {
        let cssLeft = tRect.left;
        if (cssLeft + scaledW > vw - margin) cssLeft = vw - margin - scaledW;
        if (cssLeft < margin) cssLeft = margin;
        panel.style.left = cssLeft + 'px';
        panel.style.right = 'auto';
      } else {
        let cssRight = vw - tRect.right;
        if (tRect.right - scaledW < margin) cssRight = vw - scaledW - margin;
        if (cssRight < margin) cssRight = margin;
        panel.style.right = cssRight + 'px';
        panel.style.left = 'auto';
      }
    } else {
      // ボタンが左/右辺 → パネルはボタンの横に配置
      if (edge === 'left') {
        let cssLeft = tRect.right + PANEL_GAP;
        if (cssLeft + scaledW > vw - margin) cssLeft = vw - margin - scaledW;
        if (cssLeft < margin) cssLeft = margin;
        panel.style.left = cssLeft + 'px';
        panel.style.right = 'auto';
      } else { // right
        let cssRight = vw - tRect.left + PANEL_GAP;
        if (cssRight + scaledW > vw - margin) cssRight = vw - scaledW - margin;
        if (cssRight < margin) cssRight = margin;
        panel.style.right = cssRight + 'px';
        panel.style.left = 'auto';
      }
    }

    // ── 垂直位置 ─────────────────────────────────────────────────
    if (edge === 'left' || edge === 'right') {
      // ボタンが左/右辺 → 垂直はボタンの上/下端に揃える
      if (align === 'top') {
        let cssTop = tRect.top;
        if (cssTop + scaledH > vh - margin) cssTop = vh - margin - scaledH;
        if (cssTop < margin) cssTop = margin;
        panel.style.top = cssTop + 'px';
        panel.style.bottom = 'auto';
      } else {
        let cssBottom = vh - tRect.bottom;
        if (tRect.bottom - scaledH < margin) cssBottom = vh - scaledH - margin;
        if (cssBottom < margin) cssBottom = margin;
        panel.style.bottom = cssBottom + 'px';
        panel.style.top = 'auto';
      }
    } else {
      // ボタンが上/下辺 → パネルはボタンの上or下に配置
      if (edge === 'top') {
        let cssTop = tRect.bottom + PANEL_GAP;
        if (cssTop + scaledH > vh - margin) cssTop = vh - margin - scaledH;
        if (cssTop < margin) cssTop = margin;
        panel.style.top = cssTop + 'px';
        panel.style.bottom = 'auto';
      } else { // bottom
        let cssBottom = vh - tRect.top + PANEL_GAP;
        if (cssBottom + scaledH > vh - margin) cssBottom = vh - scaledH - margin;
        if (cssBottom < margin) cssBottom = margin;
        panel.style.bottom = cssBottom + 'px';
        panel.style.top = 'auto';
      }
    }

    // ── グリッド設定 ─────────────────────────────────────────────
    const grid = document.getElementById('ovice-rs-grid');
    if (grid) {
      grid.style.gridTemplateColumns = `repeat(${cols}, minmax(48px, 1fr))`;
      const gridMaxH = finalH - chromeH;
      grid.style.maxHeight = Math.max(calcGridHeight(MIN_ROWS) + PAD * 2, gridMaxH) + 'px';
    }

    applyPanelOpacity();
    applyPanelScale();
  }

  // ── ファイルドロップで画像追加 ───────────────────────────────────
  const MAX_IMG_SIZE = 128;

  function processImageFile(file, callback, onError) {
    const reader = new FileReader();
    reader.onload = (e) => {
      if (file.type === 'image/gif') { callback(e.target.result); return; }
      const img = new Image();
      img.onload = () => {
        let url = e.target.result;
        if (img.width > MAX_IMG_SIZE || img.height > MAX_IMG_SIZE) {
          const s = MAX_IMG_SIZE / Math.max(img.width, img.height);
          const c = document.createElement('canvas');
          c.width = Math.round(img.width * s);
          c.height = Math.round(img.height * s);
          c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
          url = c.toDataURL('image/png');
        }
        callback(url);
      };
      img.onerror = () => { if (onError) onError(); };
      img.src = e.target.result;
    };
    reader.onerror = () => { if (onError) onError(); };
    reader.readAsDataURL(file);
  }

  function addFilesToReactions(files, targetCellKey) {
    const images = files.filter(f => /^image\/(png|gif|webp|jpeg)$/.test(f.type));
    if (images.length === 0) return;

    // デフォルト効果音を取得
    chrome.storage.local.get([SETTINGS_KEY], (result) => {
      const defaultSound = (result[SETTINGS_KEY] || {}).defaultSound
        || '/assets/reaction/sound/love.mp3';
      let processed = 0;
      let invalidCount = 0;
      const results = new Array(images.length).fill(null);

      const finishFile = () => {
        processed++;
        if (processed !== images.length) return;
        if (invalidCount > 0) {
          const message = `${invalidCount}件は画像形式が不正なため除外しました`;
          console.warn(`[ovice RS] ${message}`);
          showPanelToast(message);
        }
        const addedReactions = results.filter(Boolean);
        if (addedReactions.length === 0) {
          renderGrid();
          return;
        }
        reactions.push(...addedReactions);
        if (targetCellKey && !gridLayout[targetCellKey]) {
          gridLayout[targetCellKey] = addedReactions[0].id;
          newReactionIds.add(addedReactions[0].id);
        }
        // 直接配置しなかった分は syncGridLayout で空きセルに入る
        syncGridLayout();
        setLocal({
          [STORAGE_KEY]: reactions,
          [GRID_KEY]: gridLayout,
        }, () => renderGrid(), true);
      };

      images.forEach((file, index) => {
        processImageFile(file, (dataUrl) => {
          if (!isValidReactionDataUrl(dataUrl)) {
            invalidCount++;
            finishFile();
            return;
          }
          const baseName = file.name.replace(/\.[^.]+$/, '').substring(0, 20);
          const newId = Date.now().toString() + '_' + Math.random().toString(36).slice(2, 6);
          results[index] = {
            id: newId,
            name: baseName,
            dataUrl,
            sound: normalizeReactionSound(defaultSound),
          };

          finishFile();
        }, () => {
          console.warn(`[ovice RS] Failed to read image: ${file.name}`);
          finishFile();
        });
      });
    });
  }

  function setupPanelFileDrop(panel) {
    const hasFiles = (e) => Array.from(e.dataTransfer?.types || []).includes('Files');
    let dragDepth = 0;

    panel.addEventListener('dragenter', (e) => {
      if (!hasFiles(e)) return;
      e.preventDefault();
      e.stopPropagation();
      dragDepth++;
      panel.classList.add('ovice-rs-panel--file-over');
    });
    // capture: true でセルの stopPropagation より先にファイルドロップを処理
    panel.addEventListener('dragover', (e) => {
      if (!hasFiles(e)) return;
      e.preventDefault();
      e.stopPropagation();
      e.dataTransfer.dropEffect = 'copy';
    }, true);
    panel.addEventListener('dragleave', (e) => {
      if (!hasFiles(e)) return;
      e.stopPropagation();
      dragDepth = Math.max(0, dragDepth - 1);
      if (dragDepth === 0) panel.classList.remove('ovice-rs-panel--file-over');
    });
    panel.addEventListener('drop', (e) => {
      if (!hasFiles(e)) return;
      e.preventDefault();
      e.stopPropagation();
      dragDepth = 0;
      panel.classList.remove('ovice-rs-panel--file-over');
      // ドロップ先のセルキーを取得（空セル or リアクションアイテム）
      const cell = e.target.closest('.ovice-rs-cell-empty, .ovice-rs-item');
      const targetKey = cell?.dataset?.key || null;
      addFilesToReactions(Array.from(e.dataTransfer.files || []), targetKey);
    }, true);
  }

  // ── グリッド描画 ─────────────────────────────────────────────
  function renderGrid() {
    const grid  = document.getElementById('ovice-rs-grid');
    const empty = document.getElementById('ovice-rs-empty');
    if (!grid || !empty) return;
    grid.innerHTML = '';

    // リアクションが1つもなければ空メッセージ
    if (reactions.length === 0) {
      grid.style.display = 'none';
      empty.style.display = 'block';
      return;
    }
    grid.style.display = 'grid';
    empty.style.display = 'none';

    for (let row = 0; row < MAX_ROWS; row++) {
      for (let col = 0; col < MAX_COLS; col++) {
        const key = gridKey(row, col);
        const id = gridLayout[key];
        const r = id ? getReactionById(id) : null;

        if (!r) {
          // ── 空セル ────────────────────────────
          const cell = document.createElement('div');
          cell.className = 'ovice-rs-cell-empty';
          cell.dataset.key = key;

          cell.addEventListener('dragover', (e) => {
            e.preventDefault();
            e.stopPropagation();
            e.dataTransfer.dropEffect = 'move';
            cell.classList.add('ovice-rs-item--over');
          });
          cell.addEventListener('dragleave', () => cell.classList.remove('ovice-rs-item--over'));
          cell.addEventListener('drop', (e) => {
            e.preventDefault();
            e.stopPropagation();
            cell.classList.remove('ovice-rs-item--over');
            const fromKey = e.dataTransfer.getData('text/plain');
            if (!fromKey || fromKey === key) return;
            gridLayout[key] = gridLayout[fromKey];
            delete gridLayout[fromKey];
            saveGridLayout(() => renderGrid());
          });

          grid.appendChild(cell);
          continue;
        }

        // ── リアクションアイテム ────────────────
        const item = document.createElement('button');
        item.className = 'ovice-rs-item';
        item.title = r.name || '';
        item.draggable = true;
        item.dataset.key = key;

        const img = document.createElement('img');
        img.alt = r.name || '';
        img.draggable = false;
        // GIF: animateGif 設定に応じて常時アニメーション or ホバー時のみ
        if (!animateGif && r.dataUrl && r.dataUrl.startsWith('data:image/gif')) {
          const tmpImg = new Image();
          tmpImg.onload = () => {
            const canvas = document.createElement('canvas');
            canvas.width = tmpImg.width;
            canvas.height = tmpImg.height;
            canvas.getContext('2d').drawImage(tmpImg, 0, 0);
            const staticUrl = canvas.toDataURL('image/png');
            img.src = staticUrl;
            item.addEventListener('mouseenter', () => { img.src = r.dataUrl; });
            item.addEventListener('mouseleave', () => { img.src = staticUrl; });
          };
          tmpImg.onerror = () => {
            img.src = r.dataUrl;
            console.warn(`[ovice RS] Failed to freeze panel GIF: ${r.name || r.id}`);
          };
          tmpImg.src = r.dataUrl;
        } else {
          img.src = r.dataUrl;
        }
        item.appendChild(img);

        // 新規追加バッジ
        if (newReactionIds.has(r.id)) {
          const badge = document.createElement('span');
          badge.className = 'ovice-rs-new-badge';
          item.appendChild(badge);
        }

        const sendFeedback = createLatestReactionSendFeedback(
          item,
          setTimeout,
          clearTimeout,
          (reason) => console.warn('[ovice RS] Reaction send failed:', reason || 'unknown'),
        );

        item.addEventListener('click', (e) => {
          e.stopPropagation();
          sendReaction(r, sendFeedback.begin());
          // 新規バッジを消す
          if (newReactionIds.has(r.id)) {
            newReactionIds.delete(r.id);
            const badge = item.querySelector('.ovice-rs-new-badge');
            if (badge) badge.remove();
          }
        });

        // ── ドラッグ&ドロップ（位置スワップ）──────────────────────
        item.addEventListener('dragstart', (e) => {
          e.stopPropagation();
          e.dataTransfer.effectAllowed = 'move';
          e.dataTransfer.setData('text/plain', key);
          item.classList.add('ovice-rs-item--dragging');
          newReactionIds.delete(r.id);
        });
        item.addEventListener('dragend', () => {
          item.classList.remove('ovice-rs-item--dragging');
          grid.querySelectorAll('.ovice-rs-item--over').forEach(el =>
            el.classList.remove('ovice-rs-item--over')
          );
        });
        item.addEventListener('dragover', (e) => {
          e.preventDefault();
          e.stopPropagation();
          e.dataTransfer.dropEffect = 'move';
          item.classList.add('ovice-rs-item--over');
        });
        item.addEventListener('dragleave', () => {
          item.classList.remove('ovice-rs-item--over');
        });
        item.addEventListener('drop', (e) => {
          e.preventDefault();
          e.stopPropagation();
          item.classList.remove('ovice-rs-item--over');
          const fromKey = e.dataTransfer.getData('text/plain');
          if (!fromKey || fromKey === key) return;
          const tmp = gridLayout[key];
          gridLayout[key] = gridLayout[fromKey];
          if (tmp) { gridLayout[fromKey] = tmp; } else { delete gridLayout[fromKey]; }
          saveGridLayout(() => renderGrid());
        });

        grid.appendChild(item);
      }
    }
  }

  // ── 右クリック削除メニュー ────────────────────────────────────
  let activeMenu = null;
  function showDeleteMenu(x, y, reaction, gridKey) {
    dismissMenu();
    const menu = document.createElement('div');
    menu.className = 'ovice-rs-ctx-menu';

    const btn = document.createElement('button');
    btn.textContent = '「' + (reaction.name || 'reaction') + '」を削除';
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      dismissMenu();
      reactions = reactions.filter(r => r.id !== reaction.id);
      delete gridLayout[gridKey];
      newReactionIds.delete(reaction.id);
      setLocal({
        [STORAGE_KEY]: reactions,
        [GRID_KEY]: gridLayout,
      }, () => renderGrid(), true);
    });
    menu.appendChild(btn);

    // ビューポート内に収める
    document.body.appendChild(menu);
    const rect = menu.getBoundingClientRect();
    const mx = Math.min(x, window.innerWidth - rect.width - 4);
    const my = Math.min(y, window.innerHeight - rect.height - 4);
    menu.style.left = mx + 'px';
    menu.style.top = my + 'px';

    activeMenu = menu;
    setTimeout(() => {
      document.addEventListener('mousedown', dismissOnOutside);
    }, 0);
  }
  function dismissMenu() {
    if (activeMenu) { activeMenu.remove(); activeMenu = null; }
    document.removeEventListener('mousedown', dismissOnOutside);
  }
  function dismissOnOutside(e) {
    if (activeMenu && !activeMenu.contains(e.target)) dismissMenu();
  }

  // ── リアクション送信 ─────────────────────────────────────────
  function createLatestReactionSendFeedback(item, scheduleTimeout, cancelTimeout, warn) {
    let latestSendToken = 0;
    let feedbackTimeoutId = null;

    function begin() {
      latestSendToken += 1;
      const sendToken = latestSendToken;

      return (result) => {
        if (sendToken !== latestSendToken) return false;
        if (feedbackTimeoutId !== null) cancelTimeout(feedbackTimeoutId);

        const feedbackClass = result.ok ? 'ovice-rs-item--sent' : 'ovice-rs-item--failed';
        const oppositeClass = result.ok ? 'ovice-rs-item--failed' : 'ovice-rs-item--sent';
        const duration = result.ok ? 400 : 500;
        item.classList.remove(oppositeClass);
        item.classList.add(feedbackClass);
        if (!result.ok) warn(result.reason);

        const timeoutId = scheduleTimeout(() => {
          if (sendToken !== latestSendToken || feedbackTimeoutId !== timeoutId) return;
          item.classList.remove(feedbackClass);
          feedbackTimeoutId = null;
        }, duration);
        feedbackTimeoutId = timeoutId;
        return true;
      };
    }

    return { begin };
  }

  function createReactionSendTracker(dispatch, scheduleTimeout, cancelTimeout, createRequestId, timeoutMs) {
    const pending = new Map();

    function complete(detail) {
      if (!detail || !detail.requestId) return false;
      const request = pending.get(detail.requestId);
      if (!request) return false;
      cancelTimeout(request.timeoutId);
      pending.delete(detail.requestId);
      request.onResult({
        requestId: detail.requestId,
        ok: detail.ok === true,
        reason: detail.reason,
      });
      return true;
    }

    function send(reaction, onResult) {
      const requestId = createRequestId();
      const timeoutId = scheduleTimeout(() => {
        complete({ requestId, ok: false, reason: 'timeout' });
      }, timeoutMs);
      pending.set(requestId, { onResult, timeoutId });
      dispatch({
        requestId,
        name: reaction.name || 'custom',
        iconSrc: reaction.dataUrl,
        sound: reaction.sound || 'no_sound',
      });
      return requestId;
    }

    return { send, complete, pendingCount: () => pending.size };
  }

  function createReactionRequestId() {
    sendRequestSequence += 1;
    const randomPart = globalThis.crypto?.randomUUID?.() || Math.random().toString(36).slice(2);
    return `ovice-rs-${Date.now().toString(36)}-${sendRequestSequence.toString(36)}-${randomPart}`;
  }

  const reactionSendTracker = createReactionSendTracker(
    detail => window.dispatchEvent(new CustomEvent('__ovice_rs_send_reaction', { detail })),
    setTimeout,
    clearTimeout,
    createReactionRequestId,
    SEND_RESULT_TIMEOUT_MS,
  );

  window.addEventListener('__ovice_rs_send_result', (event) => {
    reactionSendTracker.complete(event.detail);
  });

  function sendReaction(reaction, onResult) {
    return reactionSendTracker.send(reaction, onResult);
  }

  // ── パネル開閉 ──────────────────────────────────────────────
  function togglePanel() { panelOpen ? closePanel() : openPanel(); }

  function openPanel() {
    panelOpen = true;
    const p = document.getElementById('ovice-rs-panel');
    const toggle = document.getElementById('ovice-rs-toggle');
    const root = document.getElementById('ovice-rs-root');
    if (p && toggle && root) {
      // right/bottom → left/top に確定（初回オープン時のズレ防止）
      const rootRect = root.getBoundingClientRect();
      root.style.right = 'auto'; root.style.bottom = 'auto';
      root.style.left = rootRect.left + 'px'; root.style.top = rootRect.top + 'px';

      const tRect = toggle.getBoundingClientRect();
      const vw = window.innerWidth;
      const vh = window.innerHeight;

      // ボタンが閉じた状態で移動されていたら、位置に応じてコーナーを再判定
      if (buttonMovedWhileClosed) {
        panelCorner = bestCornerForPosition(tRect, vw, vh);
        buttonMovedWhileClosed = false;
      }

      // スペースチェック → 現在のコーナーで収まらなければ反転
      const panelW = calcWidth(MAX_COLS) * panelScale;
      const panelH = (PANEL_CHROME_H_FALLBACK + calcGridHeight(MAX_ROWS) + PAD * 2) * panelScale;

      if (!fitsInViewport(panelCorner, tRect, panelW, panelH, vw, vh)) {
        const flipped = flipCorner(panelCorner);
        if (fitsInViewport(flipped, tRect, panelW, panelH, vw, vh)) {
          panelCorner = flipped;
        } else {
          panelCorner = bestCornerForPosition(tRect, vw, vh);
        }
      }

      applyPanelScale();
      p.classList.add('ovice-rs-panel--open');
      applyPanelSize();
    }
    toggle?.classList.add('ovice-rs-toggle--active');
    if (toggle) toggle.innerHTML = ICON_CLOSE;
  }

  function closePanel() {
    panelOpen = false;
    const p = document.getElementById('ovice-rs-panel');
    p?.classList.remove('ovice-rs-panel--open');
    const toggle = document.getElementById('ovice-rs-toggle');
    if (!popupOpen) {
      toggle?.classList.remove('ovice-rs-toggle--active');
    }
    if (toggle) toggle.innerHTML = ICON_SMILE;
  }

  // ── ovice 標準リアクションの GIF 静止化 ──────────────────────────
  // ovice ネイティブのリアクションパネル内の GIF 画像を静止表示にし、
  // ホバー時のみアニメーション再生する。
  (function freezeOviceNativeGifs() {
    const hoverHandlers = new WeakMap();
    const imageAttempts = new WeakMap();

    function removeHoverHandlers(handlers) {
      if (!handlers || hoverHandlers.get(handlers.target) !== handlers) return;
      if (handlers.enter) handlers.target.removeEventListener('mouseenter', handlers.enter);
      if (handlers.leave) handlers.target.removeEventListener('mouseleave', handlers.leave);
      hoverHandlers.delete(handlers.target);
    }

    function clearFrozenState(img, restoreGif) {
      const handlers = imageAttempts.get(img);
      if (handlers) {
        removeHoverHandlers(handlers);
        if (imageAttempts.get(img) === handlers) imageAttempts.delete(img);
      }
      if (restoreGif && img.dataset.oviceRsGifSrc) {
        img.src = img.dataset.oviceRsGifSrc;
      }
      delete img.dataset.oviceRsFrozen;
      delete img.dataset.oviceRsGifSrc;
    }

    function processGifImages() {
      const imgs = document.querySelectorAll('button.reactionButton img');
      imgs.forEach(img => {
        if (!img.src.includes('.gif') && !img.dataset.oviceRsFrozen) return;

        // animateGif ON: 凍結済みなら元に戻す
        if (animateGif) {
          if (img.dataset.oviceRsFrozen && img.dataset.oviceRsGifSrc) {
            clearFrozenState(img, true);
          }
          return;
        }

        // animateGif OFF: 未凍結のGIFを静止化
        if (img.dataset.oviceRsFrozen) return;
        img.dataset.oviceRsFrozen = 'true';

        const gifSrc = img.src;
        img.dataset.oviceRsGifSrc = gifSrc;
        const btn = img.closest('button');
        const handlers = { img, target: btn, enter: null, leave: null };
        imageAttempts.set(img, handlers);
        if (btn) {
          // ovice が同じボタン内の img だけを差し替える場合も旧リスナーを除去する
          removeHoverHandlers(hoverHandlers.get(btn));
          hoverHandlers.set(btn, handlers);
        }
        const tmpImg = new Image();
        tmpImg.crossOrigin = 'anonymous';
        tmpImg.onload = () => {
          // 設定変更や img 差し替え後に完了した旧世代の処理は無視する
          if (animateGif || imageAttempts.get(img) !== handlers
            || (btn && hoverHandlers.get(btn) !== handlers)) return;
          const canvas = document.createElement('canvas');
          canvas.width = tmpImg.width;
          canvas.height = tmpImg.height;
          canvas.getContext('2d').drawImage(tmpImg, 0, 0);
          try {
            const staticUrl = canvas.toDataURL('image/png');
            img.src = staticUrl;
            if (btn) {
              handlers.enter = () => {
                if (hoverHandlers.get(btn) === handlers) img.src = gifSrc;
              };
              handlers.leave = () => {
                if (hoverHandlers.get(btn) === handlers) img.src = staticUrl;
              };
              btn.addEventListener('mouseenter', handlers.enter);
              btn.addEventListener('mouseleave', handlers.leave);
            }
          } catch (e) {
            console.warn('[ovice RS] Cannot freeze native GIF:', e);
          }
        };
        tmpImg.onerror = () => {
          if (imageAttempts.get(img) !== handlers
            || (btn && hoverHandlers.get(btn) !== handlers)) return;
          clearFrozenState(img, false);
          console.warn(`[ovice RS] Failed to freeze native GIF: ${gifSrc}`);
        };
        tmpImg.src = gifSrc;
      });
    }

    // DOM 変更を監視して、リアクションパネルが表示されたタイミングで処理
    const observer = new MutationObserver(() => processGifImages());
    observer.observe(document.body, { childList: true, subtree: true });
    // 初回実行
    processGifImages();
  })();

  // ── ポップアップ開閉検知 ─────────────────────────────────────
  let popupOpen = false;
  chrome.runtime.onConnect.addListener((port) => {
    if (port.name === 'popup') {
      popupOpen = true;
      const toggle = document.getElementById('ovice-rs-toggle');
      toggle?.classList.add('ovice-rs-toggle--active');
      port.onDisconnect.addListener(() => {
        popupOpen = false;
        if (!panelOpen) {
          document.getElementById('ovice-rs-toggle')?.classList.remove('ovice-rs-toggle--active');
        }
      });
    }
  });
})();
