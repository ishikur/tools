/**
 * ovice Reaction Deck - Injected Script (v2.1)
 * ページコンテキストで動作。
 * content.js からカスタムイベント経由でリアクション送信指示を受け取り、
 * window.ovice の内部メソッドを使って Canvas 上にリアクションを表示する。
 * 効果音もこのスクリプトで再生する（同一オリジンのため Audio API が使える）。
 */
(function () {
  'use strict';

  // ── 不可視マーカー（標準リアクションと同じ）────────────────
  const INVISIBLE_REACTION = '\u3164\u3164\u3164';

  /**
   * カスタムリアクション用の HTML メッセージを構築。
   * ovice の Canvas レンダラは <img> タグをサポートしている。
   */
  function buildReactionHtml(name, iconSrc) {
    return '<span for="' + name + '" style="font-size: 1.5rem;">'
         + '<img src="' + iconSrc + '" width="42" height="42" style="vertical-align:middle;" />'
         + '</span>';
  }

  /**
   * 効果音を再生する。
   * ovice の効果音は同一オリジンの /assets/reaction/sound/*.mp3 にある。
   * sound が "no_sound" または空の場合は再生しない。
   */
  /**
   * ovice のオーディオ設定からリアクション音量を取得する。
   * localStorage の deviceSettings.reactionsVolume を参照。
   */
  function getOviceReactionsVolume() {
    try {
      const settings = JSON.parse(localStorage.getItem('deviceSettings') || '{}');
      return settings.reactionsVolume != null ? settings.reactionsVolume : 0.5;
    } catch (e) {
      return 0.5;
    }
  }

  function playSound(sound) {
    if (!sound || sound === 'no_sound') return;
    try {
      const url = sound.startsWith('http') ? sound : window.location.origin + sound;
      const audio = new Audio(url);
      audio.volume = Math.max(0, Math.min(1, getOviceReactionsVolume()));
      audio.play().catch(err => {
        console.warn('[ovice RS] Sound playback failed:', err);
      });
    } catch (err) {
      console.warn('[ovice RS] Sound error:', err);
    }
  }

  /**
   * カスタムリアクションを送信する。
   * 標準リアクションと同じメソッド呼び出しフローを再現:
   *   1. ovice 側の効果音を抑制（AudioBufferSourceNode.start を無効化）
   *   2. ovice.react(INVISIBLE) - リアクションバブルを表示
   *   3. ovice.chat(html)       - HTML メッセージを表示 + broadcast
   *   4. ovice.commitReaction() - アナリティクス + キャンセルタイマー
   *   5. 抑制を解除し、ovice の reactionsVolume 設定に従って効果音を再生
   */
  function sendReaction(name, iconSrc, sound) {
    const o = window.ovice;
    if (!o || !o.userId_) {
      console.warn('[ovice RS] ovice object or userId not available');
      return false;
    }

    const html = buildReactionHtml(name, iconSrc);

    // setTimeout で非同期実行：クリックイベントのハンドラ内で
    // 同期的に ovice メソッドを呼ぶと Canvas 描画と競合するため
    setTimeout(() => {
      try {
        // ovice は Web Audio API (AudioContext) で効果音を再生するため、
        // AudioBufferSourceNode.prototype.start を一時的に無効化して抑制
        const origStart = AudioBufferSourceNode.prototype.start;
        AudioBufferSourceNode.prototype.start = function () {};

        o.react(INVISIBLE_REACTION);
        o.chat(html);
        o.commitReaction();

        // 少し待ってから復元（非同期スケジュール対応）し、拡張機能の音を再生
        setTimeout(() => {
          AudioBufferSourceNode.prototype.start = origStart;
          playSound(sound);
          console.log('[ovice RS] Reaction sent:', name);
        }, 150);
      } catch (err) {
        console.warn('[ovice RS] Reaction failed:', err);
      }
    }, 50);
    return true;
  }

  // ── content.js からのイベントを受信 ──────────────────────────
  window.addEventListener('__ovice_rs_send_reaction', (e) => {
    const { name, iconSrc, sound } = e.detail || {};
    if (!name || !iconSrc) {
      console.warn('[ovice RS] Invalid reaction data:', e.detail);
      return;
    }
    const ok = sendReaction(name, iconSrc, sound);
    window.dispatchEvent(new CustomEvent('__ovice_rs_send_result', { detail: ok }));
  });

  // ── ovice オブジェクトの準備状態を返す ────────────────────────
  window.addEventListener('__ovice_rs_check_ready', () => {
    const o = window.ovice;
    const ready = !!(o && o.userId_ && typeof o.react === 'function');
    window.dispatchEvent(new CustomEvent('__ovice_rs_ready_result', { detail: ready }));
  });
})();
