/**
 * ovice Reaction Deck - Popup Script (v2.1)
 *
 * リアクション画像の追加・削除・名前編集・音設定・ソート・エクスポート/インポートを管理。
 * 画像は 128x128 にリサイズして base64 DataURL で chrome.storage.local に保存。
 */
'use strict';

const STORAGE_KEY = 'oviceReactions'; // [{ id, name, dataUrl, sound }]
const SETTINGS_KEY = 'oviceRsSettings'; // { volume, maxCols, maxRows }
const MAX_SIZE = 128; // リサイズ最大 px

const SOUNDS = [
  { value: 'no_sound',                                  label: '🔇 なし' },
  { value: '/assets/reaction/sound/positive.mp3',       label: '👍 ポジティブ' },
  { value: '/assets/reaction/sound/love.mp3',            label: '❤️ ラブ' },
  { value: '/assets/reaction/sound/haha.mp3',            label: '😄 ハハ' },
  { value: '/assets/reaction/sound/negative.mp3',        label: '👎 ネガティブ' },
  { value: '/assets/reaction/sound/negative_nope.mp3',   label: '🙅 ノープ' },
  { value: '/assets/reaction/sound/surprised.mp3',       label: '😮 サプライズ' },
  { value: '/assets/reaction/sound/question.mp3',        label: '❓ クエスチョン' },
  { value: '/assets/reaction/sound/sword.mp3',           label: '⚔️ ソード' },
  { value: '/assets/reaction/sound/wait.mp3',            label: '✋ ウェイト' },
  { value: '/assets/reaction/sound/clapping.mp3',        label: '👏 拍手' },
  { value: '/assets/reaction/sound/drum.mp3',            label: '🥁 ドラム' },
  { value: '/assets/reaction/sound/tada.mp3',            label: '🎉 タダ' },
];

let reactions = [];
let sortAsc = true; // 名前ソートの方向

// ── content script にポップアップ開閉を通知 ──────────────
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  if (tabs[0]?.id) chrome.tabs.connect(tabs[0].id, { name: 'popup' });
});

// ── 初期化 ───────────────────────────────────────────────
chrome.storage.local.get([STORAGE_KEY, 'oviceRsMigrated_allLove'], (result) => {
  reactions = result[STORAGE_KEY] || [];

  // 一回だけ: 全リアクションの音を「ラブ」に統一
  if (!result['oviceRsMigrated_allLove'] && reactions.length > 0) {
    reactions.forEach(r => { r.sound = '/assets/reaction/sound/love.mp3'; });
    chrome.storage.local.set({
      [STORAGE_KEY]: reactions,
      'oviceRsMigrated_allLove': true,
    });
  }

  renderList();
});

// ── デフォルト効果音 ─────────────────────────────────────
const defaultSoundSelect = document.getElementById('default-sound');
SOUNDS.forEach(s => {
  const opt = document.createElement('option');
  opt.value = s.value;
  opt.textContent = s.label;
  defaultSoundSelect.appendChild(opt);
});
defaultSoundSelect.value = '/assets/reaction/sound/love.mp3'; // 初期値

defaultSoundSelect.addEventListener('change', () => {
  chrome.storage.local.get([SETTINGS_KEY], (result) => {
    const s = result[SETTINGS_KEY] || {};
    s.defaultSound = defaultSoundSelect.value;
    chrome.storage.local.set({ [SETTINGS_KEY]: s });
  });
});

// デフォルト音読み込み
chrome.storage.local.get([SETTINGS_KEY], (result) => {
  const s = result[SETTINGS_KEY] || {};
  if (s.defaultSound) defaultSoundSelect.value = s.defaultSound;
});

// ── 一括効果音変更 ───────────────────────────────────────
const bulkSound = document.getElementById('bulk-sound');
SOUNDS.forEach(s => {
  const opt = document.createElement('option');
  opt.value = s.value;
  opt.textContent = s.label;
  bulkSound.appendChild(opt);
});
bulkSound.addEventListener('change', () => {
  if (!bulkSound.value || reactions.length === 0) return;
  reactions.forEach(r => { r.sound = bulkSound.value; });
  save(() => {
    renderList();
    const label = SOUNDS.find(s => s.value === bulkSound.value)?.label || '';
    toast(`全リアクションの効果音を「${label}」に変更しました`);
    bulkSound.selectedIndex = 0; // 「一括変更...」に戻す
  });
});

// ── 画像追加 ─────────────────────────────────────────────
document.getElementById('btn-add').addEventListener('click', () => {
  document.getElementById('file-input').click();
});

document.getElementById('file-input').addEventListener('change', (e) => {
  const files = Array.from(e.target.files || []);
  if (files.length === 0) return;

  let processed = 0;
  files.forEach(file => {
    processImage(file, (dataUrl) => {
      // ファイル名（拡張子除去）をデフォルト名に
      const baseName = file.name.replace(/\.[^.]+$/, '').substring(0, 20);
      reactions.push({
        id: Date.now().toString() + '_' + Math.random().toString(36).slice(2, 6),
        name: baseName,
        dataUrl,
        sound: defaultSoundSelect.value || '/assets/reaction/sound/love.mp3',
      });
      processed++;
      if (processed === files.length) {
        save(() => {
          renderList();
          toast(`${files.length}個の画像を追加しました`);
        });
      }
    });
  });

  e.target.value = ''; // 同じファイルを再選択可能に
});

/**
 * 画像をリサイズして DataURL に変換
 */
function processImage(file, callback) {
  const reader = new FileReader();
  reader.onload = (e) => {
    // GIFはcanvas変換するとアニメーションが失われるため、そのまま保存
    if (file.type === 'image/gif') {
      callback(e.target.result);
      return;
    }
    const img = new Image();
    img.onload = () => {
      let finalUrl = e.target.result;
      if (img.width > MAX_SIZE || img.height > MAX_SIZE) {
        const scale = MAX_SIZE / Math.max(img.width, img.height);
        const canvas = document.createElement('canvas');
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
        finalUrl = canvas.toDataURL('image/png');
      }
      callback(finalUrl);
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(file);
}

// ── ソートボタン ─────────────────────────────────────────
document.getElementById('btn-sort').addEventListener('click', () => {
  if (reactions.length < 2) return;
  reactions.sort((a, b) => {
    const cmp = (a.name || '').localeCompare(b.name || '', 'ja');
    return sortAsc ? cmp : -cmp;
  });
  sortAsc = !sortAsc;
  save(() => {
    renderList();
    toast(`名前順でソートしました（${sortAsc ? 'Z→A' : 'A→Z'}）`);
  });
});

// ── 一覧描画 ─────────────────────────────────────────────
function renderList() {
  const list = document.getElementById('reaction-list');
  const emptyEl = document.getElementById('empty-msg');
  const counter = document.getElementById('counter');

  // 既存のカードを削除
  Array.from(list.querySelectorAll('.reaction-card')).forEach(el => el.remove());

  if (reactions.length === 0) {
    emptyEl.style.display = 'block';
    counter.textContent = '';
    return;
  }
  emptyEl.style.display = 'none';
  counter.textContent = `${reactions.length} 個のリアクション`;

  reactions.forEach((r, idx) => {
    const card = document.createElement('div');
    card.className = 'reaction-card';

    const img = document.createElement('img');
    img.className = 'reaction-thumb';
    img.src = r.dataUrl;
    img.alt = r.name;

    const info = document.createElement('div');
    info.className = 'reaction-info';

    const nameInput = document.createElement('input');
    nameInput.className = 'reaction-name-input';
    nameInput.type = 'text';
    nameInput.value = r.name;
    nameInput.maxLength = 20;
    nameInput.placeholder = '名前';
    nameInput.addEventListener('change', () => {
      reactions[idx].name = nameInput.value.trim() || 'reaction';
      save();
    });

    // 効果音セレクト
    const soundSelect = document.createElement('select');
    soundSelect.className = 'reaction-sound-select';
    SOUNDS.forEach(s => {
      const opt = document.createElement('option');
      opt.value = s.value;
      opt.textContent = s.label;
      if (s.value === (r.sound || 'no_sound')) opt.selected = true;
      soundSelect.appendChild(opt);
    });
    soundSelect.addEventListener('change', () => {
      reactions[idx].sound = soundSelect.value;
      save();
    });

    info.appendChild(nameInput);
    info.appendChild(soundSelect);

    const delBtn = document.createElement('button');
    delBtn.className = 'btn-delete';
    delBtn.textContent = '削除';
    delBtn.addEventListener('click', () => {
      const name = reactions[idx].name;
      const scrollTop = list.scrollTop;
      reactions.splice(idx, 1);
      save(() => {
        renderList();
        list.scrollTop = scrollTop;
        toast(`「${name}」を削除しました`);
      });
    });

    card.appendChild(img);
    card.appendChild(info);
    card.appendChild(delBtn);
    list.appendChild(card);
  });
}

// ── ストレージ保存 ────────────────────────────────────────
function save(cb) {
  chrome.storage.local.set({ [STORAGE_KEY]: reactions }, () => { if (cb) cb(); });
}

// ── トースト ──────────────────────────────────────────────
let toastTimer;
function toast(msg, type = 'success') {
  const el = document.getElementById('popup-toast');
  el.textContent = msg;
  el.style.background = type === 'error' ? '#ef4444' : '#6366f1';
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 2200);
}

// ── エクスポート ──────────────────────────────────────────
document.getElementById('btn-export').addEventListener('click', () => {
  if (reactions.length === 0) { toast('エクスポートするリアクションがありません', 'error'); return; }
  chrome.storage.local.get([GRID_KEY, SETTINGS_KEY], (result) => {
    const exportData = {
      version: 3,
      reactions,
      gridLayout: result[GRID_KEY] || {},
      settings: {
        maxCols: (result[SETTINGS_KEY] || {}).maxCols || 10,
        maxRows: (result[SETTINGS_KEY] || {}).maxRows || 10,
      },
    };
    const json = JSON.stringify(exportData, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ovice-reaction-deck-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast('エクスポートしました');
  });
});

// ── インポート ──────────────────────────────────────────
document.getElementById('btn-import-input').addEventListener('change', (e) => {
  const file = e.target.files?.[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => {
    try {
      const data = JSON.parse(ev.target.result);
      const imported = data.reactions;
      if (!Array.isArray(imported)) throw new Error('形式が正しくありません');

      if (data.version >= 3 && data.gridLayout && data.settings) {
        // v3: 完全復元（既存データを置き換え）
        // IDを振り直してgridLayoutのマッピングも更新
        const idMap = {};
        imported.forEach(r => {
          const oldId = r.id;
          r.id = Date.now().toString() + '_' + Math.random().toString(36).slice(2, 6);
          idMap[oldId] = r.id;
          if (!r.sound) r.sound = defaultSoundSelect.value || '/assets/reaction/sound/love.mp3';
        });

        // gridLayout のIDを新IDに変換
        const newGrid = {};
        const gl = data.gridLayout;
        for (const key of Object.keys(gl)) {
          if (gl[key] && idMap[gl[key]]) {
            newGrid[key] = idMap[gl[key]];
          }
        }

        reactions = imported;
        currentCols = data.settings.maxCols || 10;
        currentRows = data.settings.maxRows || 10;

        chrome.storage.local.set({
          [STORAGE_KEY]: reactions,
          [GRID_KEY]: newGrid,
          [SETTINGS_KEY]: { ...(data.settings), maxCols: currentCols, maxRows: currentRows },
        }, () => {
          updateDisplay();
          renderList();
          toast(`${imported.length}個のリアクション + 配置を復元しました`);
        });
      } else {
        // v2以前: 既存に追加
        imported.forEach(r => {
          r.id = Date.now().toString() + '_' + Math.random().toString(36).slice(2, 6);
          if (!r.sound) r.sound = defaultSoundSelect.value || '/assets/reaction/sound/love.mp3';
          reactions.push(r);
        });
        save(() => {
          renderList();
          toast(`${imported.length}個のリアクションを追加しました`);
        });
      }
    } catch (err) {
      toast(`読み込み失敗: ${err.message}`, 'error');
    }
    e.target.value = '';
  };
  reader.readAsText(file);
});

// ── パネル設定（行数・列数ステッパー） ──────────────────────────
const GRID_KEY = 'oviceGridLayout';
const colsVal = document.getElementById('cols-val');
const rowsVal = document.getElementById('rows-val');
let currentCols = 10, currentRows = 10;
let minCols = 3, minRows = 2;

/** gridLayout から配置済みリアクションの最大行・列を取得 */
function getMinGridSize(gridLayout) {
  let mc = 3, mr = 2;
  if (!gridLayout) return { minCols: mc, minRows: mr };

  if (Array.isArray(gridLayout)) {
    const oldCols = 10;
    gridLayout.forEach((id, idx) => {
      if (id != null) {
        mc = Math.max(mc, (idx % oldCols) + 1);
        mr = Math.max(mr, Math.floor(idx / oldCols) + 1);
      }
    });
  } else if (typeof gridLayout === 'object') {
    for (const key of Object.keys(gridLayout)) {
      if (gridLayout[key]) {
        const [r, c] = key.split(',').map(Number);
        mc = Math.max(mc, c + 1);
        mr = Math.max(mr, r + 1);
      }
    }
  }
  return { minCols: mc, minRows: mr };
}

function updateDisplay() {
  colsVal.textContent = currentCols;
  rowsVal.textContent = currentRows;
}

function saveSettings() {
  chrome.storage.local.get([SETTINGS_KEY], (result) => {
    const s = result[SETTINGS_KEY] || {};
    s.maxCols = currentCols;
    s.maxRows = currentRows;
    chrome.storage.local.set({ [SETTINGS_KEY]: s });
  });
}

function adjustCols(delta) {
  const next = currentCols + delta;
  if (next < minCols || next > 20) return;
  currentCols = next;
  updateDisplay();
  saveSettings();
}

function adjustRows(delta) {
  const next = currentRows + delta;
  if (next < minRows || next > 20) return;
  currentRows = next;
  updateDisplay();
  saveSettings();
}

// 読み込み
chrome.storage.local.get([SETTINGS_KEY, GRID_KEY], (result) => {
  const s = result[SETTINGS_KEY] || {};
  if (s.maxCols) currentCols = s.maxCols;
  if (s.maxRows) currentRows = s.maxRows;
  const limits = getMinGridSize(result[GRID_KEY]);
  minCols = limits.minCols;
  minRows = limits.minRows;
  updateDisplay();
});

document.getElementById('cols-dec').addEventListener('click', () => adjustCols(-1));
document.getElementById('cols-inc').addEventListener('click', () => adjustCols(1));
document.getElementById('rows-dec').addEventListener('click', () => adjustRows(-1));
document.getElementById('rows-inc').addEventListener('click', () => adjustRows(1));

// ── 透明度スライダー ──────────────────────────────────────
const opacitySlider = document.getElementById('setting-opacity');
const opacityVal = document.getElementById('opacity-val');

opacitySlider.addEventListener('input', () => {
  opacityVal.textContent = opacitySlider.value + '%';
});
opacitySlider.addEventListener('change', () => {
  chrome.storage.local.get([SETTINGS_KEY], (result) => {
    const s = result[SETTINGS_KEY] || {};
    s.panelOpacity = parseInt(opacitySlider.value, 10);
    chrome.storage.local.set({ [SETTINGS_KEY]: s });
  });
});

// 読み込み
chrome.storage.local.get([SETTINGS_KEY], (result) => {
  const s = result[SETTINGS_KEY] || {};
  const opacity = s.panelOpacity != null ? s.panelOpacity : 75;
  opacitySlider.value = opacity;
  opacityVal.textContent = opacity + '%';
});

// ── GIFアニメーション設定 ────────────────────────────────
const animateGifCheckbox = document.getElementById('setting-animate-gif');
animateGifCheckbox.addEventListener('change', () => {
  chrome.storage.local.get([SETTINGS_KEY], (result) => {
    const s = result[SETTINGS_KEY] || {};
    s.animateGif = animateGifCheckbox.checked;
    chrome.storage.local.set({ [SETTINGS_KEY]: s });
  });
});

chrome.storage.local.get([SETTINGS_KEY], (result) => {
  const s = result[SETTINGS_KEY] || {};
  animateGifCheckbox.checked = !!s.animateGif;
});
