/**
 * ovice Reaction Deck - Popup Script (v2.1)
 *
 * リアクション画像の追加・削除・名前編集・音設定・ソート・エクスポート/インポートを管理。
 * 画像は 128x128 にリサイズして base64 DataURL で chrome.storage.local に保存。
 */
'use strict';

const STORAGE_KEY = 'oviceReactions'; // [{ id, name, dataUrl, sound }]
const SETTINGS_KEY = 'oviceRsSettings';
const MAX_SIZE = 128; // リサイズ最大 px

const SOUNDS = [
  { value: 'no_sound',                                  label: '🔇 なし' },
  { value: '/assets/reaction/sound/positive.mp3',       label: '👍 ポジティブ' },
  { value: '/assets/reaction/sound/love.mp3',            label: '❤️ ラブ' },
  { value: '/assets/reaction/sound/haha.mp3',            label: '😄 ハハ' },
  { value: '/assets/reaction/sound/negative.mp3',        label: '👎 ネガティブ' },
  { value: '/assets/reaction/sound/negative_nope.mp3',   label: '🙅 ノープ' },
  { value: '/assets/reaction/sound/surprised.mp3',       label: '😮 サプライズ' },
  { value: '/assets/reaction/sound/question.mp3',        label: '❓ クエスチョン' },
  { value: '/assets/reaction/sound/sword.mp3',           label: '⚔️ ソード' },
  { value: '/assets/reaction/sound/wait.mp3',            label: '✋ ウェイト' },
  { value: '/assets/reaction/sound/clapping.mp3',        label: '👏 拍手' },
  { value: '/assets/reaction/sound/drum.mp3',            label: '🥁 ドラム' },
  { value: '/assets/reaction/sound/tada.mp3',            label: '🎉 タダ' },
];
const REACTION_IMAGE_DATA_URL_PATTERN = /^data:image\/(png|gif|webp|jpeg);base64,[A-Za-z0-9+/=\x20]*$/;

function isValidReactionDataUrl(dataUrl) {
  return typeof dataUrl === 'string' && REACTION_IMAGE_DATA_URL_PATTERN.test(dataUrl);
}

function normalizeReactionSound(sound) {
  return SOUNDS.some(item => item.value === sound) ? sound : 'no_sound';
}

function countHiddenReactions(total, settings) {
  const maxRows = Number.isFinite(settings?.maxRows) && settings.maxRows > 0
    ? settings.maxRows
    : 10;
  const maxCols = Number.isFinite(settings?.maxCols) && settings.maxCols > 0
    ? settings.maxCols
    : 10;
  return Math.max(0, total - (maxRows * maxCols));
}

function notifyHiddenReactions(total, settings) {
  const hiddenCount = countHiddenReactions(total, settings);
  const notice = document.querySelector?.('#hidden-reactions-notice');
  if (!notice) return;
  if (hiddenCount > 0) {
    notice.textContent = `パネルに空きがありません。${hiddenCount}個が表示されていません。行数・列数を増やしてください`;
    notice.style.display = 'block';
  } else {
    notice.textContent = '';
    notice.style.display = 'none';
  }
}

function loadSettingsAndNotifyHiddenReactions(total) {
  if (typeof chrome === 'undefined') return;
  chrome.storage.local.get([SETTINGS_KEY], (result) => {
    notifyHiddenReactions(total, result[SETTINGS_KEY]);
  });
}

const EXPORTED_SETTING_KEYS = [
  'defaultSound',
  'maxCols',
  'maxRows',
  'panelOpacity',
  'animateGif',
  'panelScale',
  'panelCorner',
  'togglePos',
  'volume',
];
const PANEL_CORNERS = new Set([
  'top-left', 'top-right', 'bottom-left', 'bottom-right',
  'left-top', 'left-bottom', 'right-top', 'right-bottom',
]);
const TOGGLE_POSITION_ANCHORS = new Set([
  'left-top', 'left-bottom', 'right-top', 'right-bottom',
]);

function copyExportSettings(settings) {
  const exported = {};
  const source = settings && typeof settings === 'object' && !Array.isArray(settings)
    ? settings
    : {};
  for (const key of EXPORTED_SETTING_KEYS) {
    if (Object.hasOwn(source, key)) exported[key] = source[key];
  }
  return exported;
}

function buildExportData(exportedReactions, gridLayout, settings) {
  return {
    version: 4,
    reactions: exportedReactions,
    gridLayout: gridLayout || {},
    settings: copyExportSettings(settings),
  };
}

function isFiniteNumberInRange(value, min, max) {
  return typeof value === 'number' && Number.isFinite(value) && value >= min && value <= max;
}

function isValidTogglePos(value) {
  return value !== null
    && typeof value === 'object'
    && !Array.isArray(value)
    && TOGGLE_POSITION_ANCHORS.has(value.anchor)
    && isFiniteNumberInRange(value.offsetX, 0, Number.MAX_SAFE_INTEGER)
    && isFiniteNumberInRange(value.offsetY, 0, Number.MAX_SAFE_INTEGER);
}

function mergeImportedSettings(currentSettings, importedSettings) {
  const current = currentSettings && typeof currentSettings === 'object' && !Array.isArray(currentSettings)
    ? currentSettings
    : {};
  const merged = { ...current };
  if (!importedSettings || typeof importedSettings !== 'object' || Array.isArray(importedSettings)) {
    return merged;
  }

  if (Object.hasOwn(importedSettings, 'defaultSound')
      && SOUNDS.some(item => item.value === importedSettings.defaultSound)) {
    merged.defaultSound = importedSettings.defaultSound;
  }
  if (Object.hasOwn(importedSettings, 'maxCols')
      && Number.isInteger(importedSettings.maxCols)
      && isFiniteNumberInRange(importedSettings.maxCols, 3, 20)) {
    merged.maxCols = importedSettings.maxCols;
  }
  if (Object.hasOwn(importedSettings, 'maxRows')
      && Number.isInteger(importedSettings.maxRows)
      && isFiniteNumberInRange(importedSettings.maxRows, 2, 20)) {
    merged.maxRows = importedSettings.maxRows;
  }
  if (Object.hasOwn(importedSettings, 'panelOpacity')
      && isFiniteNumberInRange(importedSettings.panelOpacity, 0, 100)) {
    merged.panelOpacity = importedSettings.panelOpacity;
  }
  if (Object.hasOwn(importedSettings, 'animateGif')
      && typeof importedSettings.animateGif === 'boolean') {
    merged.animateGif = importedSettings.animateGif;
  }
  if (Object.hasOwn(importedSettings, 'panelScale')
      && isFiniteNumberInRange(importedSettings.panelScale, 0.5, 2)) {
    merged.panelScale = importedSettings.panelScale;
  }
  if (Object.hasOwn(importedSettings, 'panelCorner')
      && PANEL_CORNERS.has(importedSettings.panelCorner)) {
    merged.panelCorner = importedSettings.panelCorner;
  }
  if (Object.hasOwn(importedSettings, 'togglePos') && isValidTogglePos(importedSettings.togglePos)) {
    merged.togglePos = {
      anchor: importedSettings.togglePos.anchor,
      offsetX: importedSettings.togglePos.offsetX,
      offsetY: importedSettings.togglePos.offsetY,
    };
  }
  if (Object.hasOwn(importedSettings, 'volume')
      && isFiniteNumberInRange(importedSettings.volume, 0, 1)) {
    merged.volume = importedSettings.volume;
  }
  return merged;
}

function prepareImportedReactions(imported) {
  const idMap = Object.create(null);
  const validReactions = [];
  let skippedCount = 0;

  imported.forEach(reaction => {
    if (!reaction || !isValidReactionDataUrl(reaction.dataUrl)) {
      skippedCount++;
      return;
    }
    const newId = Date.now().toString() + '_' + Math.random().toString(36).slice(2, 6);
    idMap[reaction.id] = newId;
    validReactions.push({
      ...reaction,
      id: newId,
      sound: normalizeReactionSound(reaction.sound),
    });
  });

  return { validReactions, idMap, skippedCount };
}

let reactions = [];
let sortAsc = true; // 名前ソートの方向
let pendingExternalReactions = null;
const pendingOwnSaves = [];

function reactionsSnapshot(value) {
  return JSON.stringify(value || []);
}

function markOwnSave(value) {
  const snapshot = reactionsSnapshot(value);
  pendingOwnSaves.push(snapshot);
  return snapshot;
}

function unmarkOwnSave(snapshot) {
  const index = pendingOwnSaves.indexOf(snapshot);
  if (index >= 0) pendingOwnSaves.splice(index, 1);
}

function consumeOwnSave(value) {
  const snapshot = reactionsSnapshot(value);
  const index = pendingOwnSaves.indexOf(snapshot);
  if (index < 0) return false;
  pendingOwnSaves.splice(index, 1);
  return true;
}

function renderListPreservingScroll() {
  const list = document.getElementById('reaction-list');
  const scrollTop = list.scrollTop;
  renderList();
  list.scrollTop = scrollTop;
}

function hasFocusedNameInput() {
  return document.activeElement?.classList.contains('reaction-name-input');
}

function applyPendingExternalReactions() {
  if (!pendingExternalReactions || hasFocusedNameInput()) return;
  reactions = pendingExternalReactions;
  pendingExternalReactions = null;
  renderListPreservingScroll();
}

/**
 * 保留中の外部更新を含む最新配列に対して変更を適用し、保存する。
 * mutator 内で個別要素を扱う場合は、描画時の index ではなく id で再検索する。
 */
function mutateReactions(mutator, cb) {
  const hadPendingExternal = pendingExternalReactions !== null;
  const latest = hadPendingExternal ? pendingExternalReactions : reactions;
  pendingExternalReactions = null;
  reactions = latest.map(reaction => ({ ...reaction }));

  if (mutator(reactions) === false) {
    if (hadPendingExternal) renderListPreservingScroll();
    return false;
  }

  save(() => {
    if (cb) cb();
    else if (hadPendingExternal) renderListPreservingScroll();
  });
  return true;
}

// ── content script にポップアップ開閉を通知 ──────────────
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  if (tabs[0]?.id) {
    const port = chrome.tabs.connect(tabs[0].id, { name: 'popup' });
    port.onDisconnect.addListener(() => void chrome.runtime.lastError);
  }
});

// ── 初期化 ───────────────────────────────────────────────
chrome.storage.local.get([STORAGE_KEY], (result) => {
  reactions = result[STORAGE_KEY] || [];
  renderList();
});

// パネルなど別コンテキストの更新を取り込む。名前編集中は blur まで描画を保留する。
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  // 配置が変わったら行数・列数の下限を取り直す。
  // これをしないと、ポップアップを開いたままパネル側で配置が広がった場合に
  // 古い下限が残り、配置済みのリアクションを切り捨てる方向に減らせてしまう。
  if (typeof getMinGridSize === 'function' && changes[GRID_KEY]) {
    const limits = getMinGridSize(changes[GRID_KEY].newValue);
    minCols = limits.minCols;
    minRows = limits.minRows;
  }
  if (!changes[STORAGE_KEY]) return;
  const nextReactions = changes[STORAGE_KEY].newValue || [];
  if (consumeOwnSave(nextReactions)) return;
  if (typeof loadSettingsAndNotifyHiddenReactions === 'function') {
    loadSettingsAndNotifyHiddenReactions(nextReactions.length);
  }

  if (hasFocusedNameInput()) {
    pendingExternalReactions = nextReactions;
    return;
  }

  reactions = nextReactions;
  renderListPreservingScroll();
});

// ── デフォルト効果音 ─────────────────────────────────────
const defaultSoundSelect = document.getElementById('default-sound');
SOUNDS.forEach(s => {
  const opt = document.createElement('option');
  opt.value = s.value;
  opt.textContent = s.label;
  defaultSoundSelect.appendChild(opt);
});
defaultSoundSelect.value = '/assets/reaction/sound/love.mp3'; // 初期値

defaultSoundSelect.addEventListener('change', () => {
  chrome.storage.local.get([SETTINGS_KEY], (result) => {
    const s = result[SETTINGS_KEY] || {};
    s.defaultSound = defaultSoundSelect.value;
    setLocal({ [SETTINGS_KEY]: s });
  });
});

// デフォルト音読み込み
chrome.storage.local.get([SETTINGS_KEY], (result) => {
  const s = result[SETTINGS_KEY] || {};
  if (s.defaultSound) defaultSoundSelect.value = s.defaultSound;
});

// ── 一括効果音変更 ───────────────────────────────────────
const bulkSound = document.getElementById('bulk-sound');
SOUNDS.forEach(s => {
  const opt = document.createElement('option');
  opt.value = s.value;
  opt.textContent = s.label;
  bulkSound.appendChild(opt);
});
bulkSound.addEventListener('change', () => {
  if (!bulkSound.value) return;
  const sound = bulkSound.value;
  mutateReactions(latest => {
    if (latest.length === 0) return false;
    latest.forEach(r => { r.sound = sound; });
  }, () => {
    renderList();
    const label = SOUNDS.find(s => s.value === sound)?.label || '';
    toast(`全リアクションの効果音を「${label}」に変更しました`);
    bulkSound.selectedIndex = 0; // 「一括変更...」に戻す
  });
});

// ── 画像追加 ─────────────────────────────────────────────
document.getElementById('btn-add').addEventListener('click', () => {
  document.getElementById('file-input').click();
});

document.getElementById('file-input').addEventListener('change', (e) => {
  const files = Array.from(e.target.files || []);
  addFiles(files);
  e.target.value = ''; // 同じファイルを再選択可能に
});

/**
 * 画像ファイル群をリアクションとして追加する。
 * file-input / ドラッグ&ドロップ 共通。
 */
function addFiles(files) {
  const images = files.filter(f => /^image\/(png|gif|webp|jpeg)$/.test(f.type));
  if (images.length === 0) {
    if (files.length > 0) toast('画像ファイルを選んでください', 'error');
    return;
  }

  let processed = 0;
  let invalidCount = 0;
  let totalAfterSave = 0;
  const addedReactions = [];
  const finishFile = () => {
    processed++;
    if (processed !== images.length) return;
    if (addedReactions.length === 0) {
      if (invalidCount > 0) toast(`${invalidCount}件は画像形式が不正なため除外しました`, 'error');
      return;
    }
    mutateReactions(latest => {
      latest.push(...addedReactions);
      totalAfterSave = latest.length;
    }, () => {
      renderList();
      if (invalidCount > 0) toast(`${invalidCount}件は画像形式が不正なため除外しました`, 'error');
      else toast(`${addedReactions.length}個の画像を追加しました`);
      loadSettingsAndNotifyHiddenReactions(totalAfterSave);
    });
  };
  images.forEach(file => {
    processImage(file, (dataUrl) => {
      if (!isValidReactionDataUrl(dataUrl)) {
        invalidCount++;
        finishFile();
        return;
      }
      const baseName = file.name.replace(/\.[^.]+$/, '').substring(0, 20);
      const addedReaction = {
        id: Date.now().toString() + '_' + Math.random().toString(36).slice(2, 6),
        name: baseName,
        dataUrl,
        sound: normalizeReactionSound(defaultSoundSelect.value),
      };
      addedReactions.push(addedReaction);
      finishFile();
    }, () => {
      toast(`画像の読み込みに失敗しました: ${file.name}`, 'error');
      finishFile();
    });
  });
}

// ── ドラッグ&ドロップで画像追加 ──────────────────────────
(function setupDragDrop() {
  const overlay = document.createElement('div');
  overlay.id = 'popup-drop-overlay';
  overlay.textContent = 'ドロップして追加';
  document.body.appendChild(overlay);

  let dragDepth = 0;
  const hasFiles = (e) => Array.from(e.dataTransfer?.types || []).includes('Files');

  window.addEventListener('dragenter', (e) => {
    if (!hasFiles(e)) return;
    e.preventDefault();
    dragDepth++;
    overlay.classList.add('show');
  });
  window.addEventListener('dragover', (e) => {
    if (!hasFiles(e)) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
  });
  window.addEventListener('dragleave', (e) => {
    if (!hasFiles(e)) return;
    dragDepth = Math.max(0, dragDepth - 1);
    if (dragDepth === 0) overlay.classList.remove('show');
  });
  window.addEventListener('drop', (e) => {
    if (!hasFiles(e)) return;
    e.preventDefault();
    dragDepth = 0;
    overlay.classList.remove('show');
    addFiles(Array.from(e.dataTransfer.files || []));
  });
})();

/**
 * 画像をリサイズして DataURL に変換
 */
function processImage(file, callback, onError) {
  const reader = new FileReader();
  reader.onload = (e) => {
    // GIFはcanvas変換するとアニメーションが失われるため、そのまま保存
    if (file.type === 'image/gif') {
      callback(e.target.result);
      return;
    }
    const img = new Image();
    img.onload = () => {
      let finalUrl = e.target.result;
      if (img.width > MAX_SIZE || img.height > MAX_SIZE) {
        const scale = MAX_SIZE / Math.max(img.width, img.height);
        const canvas = document.createElement('canvas');
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
        finalUrl = canvas.toDataURL('image/png');
      }
      callback(finalUrl);
    };
    img.onerror = () => { if (onError) onError(); };
    img.src = e.target.result;
  };
  reader.onerror = () => { if (onError) onError(); };
  reader.readAsDataURL(file);
}

// ── ソートボタン ─────────────────────────────────────────
document.getElementById('btn-sort').addEventListener('click', () => {
  const ascending = sortAsc;
  mutateReactions(latest => {
    if (latest.length < 2) return false;
    latest.sort((a, b) => {
      const cmp = (a.name || '').localeCompare(b.name || '', 'ja');
      return ascending ? cmp : -cmp;
    });
    sortAsc = !sortAsc;
  }, () => {
    renderList();
    toast(`名前順でソートしました（${sortAsc ? 'Z→A' : 'A→Z'}）`);
  });
});

// ── 一覧描画 ─────────────────────────────────────────────
function renderList() {
  const list = document.getElementById('reaction-list');
  const emptyEl = document.getElementById('empty-msg');
  const counter = document.getElementById('counter');

  // 既存のカードを削除
  Array.from(list.querySelectorAll('.reaction-card')).forEach(el => el.remove());

  if (reactions.length === 0) {
    emptyEl.style.display = 'block';
    counter.textContent = '';
    return;
  }
  emptyEl.style.display = 'none';
  counter.textContent = `${reactions.length} 個のリアクション`;

  reactions.forEach((r) => {
    const card = document.createElement('div');
    card.className = 'reaction-card';

    const img = document.createElement('img');
    img.className = 'reaction-thumb';
    img.src = r.dataUrl;
    img.alt = r.name;

    const info = document.createElement('div');
    info.className = 'reaction-info';

    const nameInput = document.createElement('input');
    nameInput.className = 'reaction-name-input';
    nameInput.type = 'text';
    nameInput.value = r.name;
    nameInput.maxLength = 20;
    nameInput.placeholder = '名前';
    nameInput.addEventListener('change', () => {
      const name = nameInput.value.trim() || 'reaction';
      const reactionId = r.id;
      mutateReactions(latest => {
        const target = latest.find(item => item.id === reactionId);
        if (!target) return false;
        target.name = name;
      });
    });
    // blur を起点にしたクリックを妨げないよう、同じ操作の click 完了後に反映する。
    nameInput.addEventListener('blur', () => setTimeout(applyPendingExternalReactions, 0));

    // 効果音セレクト
    const soundSelect = document.createElement('select');
    soundSelect.className = 'reaction-sound-select';
    SOUNDS.forEach(s => {
      const opt = document.createElement('option');
      opt.value = s.value;
      opt.textContent = s.label;
      if (s.value === (r.sound || 'no_sound')) opt.selected = true;
      soundSelect.appendChild(opt);
    });
    soundSelect.addEventListener('change', () => {
      const reactionId = r.id;
      const sound = soundSelect.value;
      mutateReactions(latest => {
        const target = latest.find(item => item.id === reactionId);
        if (!target) return false;
        target.sound = sound;
      });
    });

    info.appendChild(nameInput);
    info.appendChild(soundSelect);

    const delBtn = document.createElement('button');
    delBtn.className = 'btn-delete';
    delBtn.textContent = '削除';
    delBtn.addEventListener('click', () => {
      const reactionId = r.id;
      const scrollTop = list.scrollTop;
      let deletedName = r.name;
      mutateReactions(latest => {
        const latestIndex = latest.findIndex(item => item.id === reactionId);
        if (latestIndex < 0) return false;
        deletedName = latest[latestIndex].name;
        latest.splice(latestIndex, 1);
      }, () => {
        renderList();
        list.scrollTop = scrollTop;
        toast(`「${deletedName}」を削除しました`);
        if (typeof loadSettingsAndNotifyHiddenReactions === 'function') {
          loadSettingsAndNotifyHiddenReactions(reactions.length);
        }
      });
    });

    card.appendChild(img);
    card.appendChild(info);
    card.appendChild(delBtn);
    list.appendChild(card);
  });
}

// ── ストレージ保存 ────────────────────────────────────────
const STORAGE_SAVE_ERROR_MESSAGE = '保存に失敗しました(容量不足の可能性があります)';

function showStorageSaveError(error) {
  console.warn('[ovice RS] Storage save failed:', error?.message || error);
  toast(STORAGE_SAVE_ERROR_MESSAGE, 'error');
}

function setLocal(values, onSuccess, onError) {
  chrome.storage.local.set(values, () => {
    const error = chrome.runtime.lastError;
    if (error) {
      showStorageSaveError(error);
      if (onError) onError();
      return;
    }
    if (onSuccess) onSuccess();
  });
}

function reloadReactions() {
  chrome.storage.local.get([STORAGE_KEY], (result) => {
    reactions = result[STORAGE_KEY] || [];
    pendingExternalReactions = null;
    renderList();
  });
}

function save(cb) {
  const ownSave = markOwnSave(reactions);
  setLocal({ [STORAGE_KEY]: reactions }, cb, () => {
    unmarkOwnSave(ownSave);
    reloadReactions();
  });
}

// ── トースト ──────────────────────────────────────────────
let toastTimer;
function toast(msg, type = 'success') {
  const el = document.getElementById('popup-toast');
  el.textContent = msg;
  el.style.background = type === 'error' ? '#ef4444' : '#6366f1';
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 2200);
}

// ── エクスポート ──────────────────────────────────────────
document.getElementById('btn-export').addEventListener('click', () => {
  if (reactions.length === 0) { toast('エクスポートするリアクションがありません', 'error'); return; }
  chrome.storage.local.get([GRID_KEY, SETTINGS_KEY], (result) => {
    const exportData = buildExportData(reactions, result[GRID_KEY], result[SETTINGS_KEY]);
    const json = JSON.stringify(exportData, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ovice-reaction-deck-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast('エクスポートしました');
  });
});

// ── インポート ──────────────────────────────────────────
document.getElementById('btn-import-input').addEventListener('change', (e) => {
  const file = e.target.files?.[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => {
    try {
      const data = JSON.parse(ev.target.result);
      const imported = data.reactions;
      if (!Array.isArray(imported)) throw new Error('形式が正しくありません');
      const { validReactions, idMap, skippedCount } = prepareImportedReactions(imported);
      const showImportToast = successMessage => {
        if (skippedCount > 0) toast(`${skippedCount}件は画像形式が不正なため除外しました`, 'error');
        else toast(successMessage);
      };

      if (data.version >= 3 && data.gridLayout && data.settings) {
        // v3/v4: 完全復元（既存データを置き換え、設定は現在値へマージ）
        // 完全復元は全置き換えが仕様: 保留中の外部変更より復元内容を優先する。
        // IDを振り直してgridLayoutのマッピングも更新
        if (imported.length > 0 && validReactions.length === 0) {
          toast('すべての項目が不正のため取り込みませんでした', 'error');
          e.target.value = '';
          return;
        }

        // gridLayout のIDを新IDに変換
        const newGrid = Object.create(null);
        const gl = data.gridLayout;
        for (const key of Object.keys(gl)) {
          if (gl[key] && Object.hasOwn(idMap, gl[key])) {
            newGrid[key] = idMap[gl[key]];
          }
        }

        chrome.storage.local.get([SETTINGS_KEY], (settingsResult) => {
          const mergedSettings = mergeImportedSettings(settingsResult[SETTINGS_KEY], data.settings);
          reactions = validReactions;
          currentCols = mergedSettings.maxCols || 10;
          currentRows = mergedSettings.maxRows || 10;

          const ownSave = markOwnSave(reactions);
          setLocal({
            [STORAGE_KEY]: reactions,
            [GRID_KEY]: newGrid,
            [SETTINGS_KEY]: mergedSettings,
          }, () => {
            updateDisplay();
            renderList();
            showImportToast(`${validReactions.length}個のリアクション + 配置を復元しました`);
            notifyHiddenReactions(reactions.length, mergedSettings);
          }, () => {
            unmarkOwnSave(ownSave);
            chrome.storage.local.get([STORAGE_KEY, SETTINGS_KEY], (result) => {
              reactions = result[STORAGE_KEY] || [];
              pendingExternalReactions = null;
              const savedSettings = result[SETTINGS_KEY] || {};
              currentCols = savedSettings.maxCols || 10;
              currentRows = savedSettings.maxRows || 10;
              updateDisplay();
              renderList();
            });
          });
        });
      } else {
        // v2以前: 既存に追加
        const addedReactions = validReactions;
        let totalAfterSave = 0;
        mutateReactions(latest => {
          latest.push(...addedReactions);
          totalAfterSave = latest.length;
        }, () => {
          renderList();
          showImportToast(`${addedReactions.length}個のリアクションを追加しました`);
          loadSettingsAndNotifyHiddenReactions(totalAfterSave);
        });
      }
    } catch (err) {
      toast(`読み込み失敗: ${err.message}`, 'error');
    }
    e.target.value = '';
  };
  reader.onerror = () => {
    toast(`読み込み失敗: ${file.name}`, 'error');
    e.target.value = '';
  };
  reader.readAsText(file);
});

// ── パネル設定（行数・列数ステッパー） ──────────────────────────
const GRID_KEY = 'oviceGridLayout';
const colsVal = document.getElementById('cols-val');
const rowsVal = document.getElementById('rows-val');
let currentCols = 10, currentRows = 10;
let minCols = 3, minRows = 2;

/** gridLayout から配置済みリアクションの最大行・列を取得 */
function getMinGridSize(gridLayout) {
  let mc = 3, mr = 2;
  if (!gridLayout) return { minCols: mc, minRows: mr };

  if (Array.isArray(gridLayout)) {
    const oldCols = 10;
    gridLayout.forEach((id, idx) => {
      if (id != null) {
        mc = Math.max(mc, (idx % oldCols) + 1);
        mr = Math.max(mr, Math.floor(idx / oldCols) + 1);
      }
    });
  } else if (typeof gridLayout === 'object') {
    for (const key of Object.keys(gridLayout)) {
      if (gridLayout[key]) {
        const [r, c] = key.split(',').map(Number);
        mc = Math.max(mc, c + 1);
        mr = Math.max(mr, r + 1);
      }
    }
  }
  return { minCols: mc, minRows: mr };
}

function updateDisplay() {
  colsVal.textContent = currentCols;
  rowsVal.textContent = currentRows;
}

function saveSettings(onSuccess) {
  chrome.storage.local.get([SETTINGS_KEY], (result) => {
    const s = result[SETTINGS_KEY] || {};
    s.maxCols = currentCols;
    s.maxRows = currentRows;
    setLocal({ [SETTINGS_KEY]: s }, () => {
      if (onSuccess) onSuccess(s);
    });
  });
}

function adjustCols(delta) {
  const next = currentCols + delta;
  if (next < minCols || next > 20) return;
  currentCols = next;
  updateDisplay();
  saveSettings((savedSettings) => {
    notifyHiddenReactions(reactions.length, savedSettings);
  });
}

function adjustRows(delta) {
  const next = currentRows + delta;
  if (next < minRows || next > 20) return;
  currentRows = next;
  updateDisplay();
  saveSettings((savedSettings) => {
    notifyHiddenReactions(reactions.length, savedSettings);
  });
}

// 読み込み
chrome.storage.local.get([SETTINGS_KEY, GRID_KEY, STORAGE_KEY], (result) => {
  const s = result[SETTINGS_KEY] || {};
  if (s.maxCols) currentCols = s.maxCols;
  if (s.maxRows) currentRows = s.maxRows;
  const limits = getMinGridSize(result[GRID_KEY]);
  minCols = limits.minCols;
  minRows = limits.minRows;
  updateDisplay();
  notifyHiddenReactions((result[STORAGE_KEY] || []).length, s);
});

document.getElementById('cols-dec').addEventListener('click', () => adjustCols(-1));
document.getElementById('cols-inc').addEventListener('click', () => adjustCols(1));
document.getElementById('rows-dec').addEventListener('click', () => adjustRows(-1));
document.getElementById('rows-inc').addEventListener('click', () => adjustRows(1));

// ── 透明度スライダー ──────────────────────────────────────
const opacitySlider = document.getElementById('setting-opacity');
const opacityVal = document.getElementById('opacity-val');

opacitySlider.addEventListener('input', () => {
  opacityVal.textContent = opacitySlider.value + '%';
});
opacitySlider.addEventListener('change', () => {
  chrome.storage.local.get([SETTINGS_KEY], (result) => {
    const s = result[SETTINGS_KEY] || {};
    s.panelOpacity = parseInt(opacitySlider.value, 10);
    setLocal({ [SETTINGS_KEY]: s });
  });
});

// 読み込み
chrome.storage.local.get([SETTINGS_KEY], (result) => {
  const s = result[SETTINGS_KEY] || {};
  const opacity = s.panelOpacity != null ? s.panelOpacity : 75;
  opacitySlider.value = opacity;
  opacityVal.textContent = opacity + '%';
});

// ── GIFアニメーション設定 ────────────────────────────────
const animateGifCheckbox = document.getElementById('setting-animate-gif');
animateGifCheckbox.addEventListener('change', () => {
  chrome.storage.local.get([SETTINGS_KEY], (result) => {
    const s = result[SETTINGS_KEY] || {};
    s.animateGif = animateGifCheckbox.checked;
    setLocal({ [SETTINGS_KEY]: s });
  });
});

chrome.storage.local.get([SETTINGS_KEY], (result) => {
  const s = result[SETTINGS_KEY] || {};
  animateGifCheckbox.checked = !!s.animateGif;
});

// ── トグルボタン位置リセット ────────────────────────────
const resetTogglePosBtn = document.getElementById('btn-reset-toggle-pos');
if (resetTogglePosBtn) {
  resetTogglePosBtn.addEventListener('click', () => {
    chrome.storage.local.get([SETTINGS_KEY], (result) => {
      const s = result[SETTINGS_KEY] || {};
      delete s.togglePos;
      setLocal({ [SETTINGS_KEY]: s }, () => {
        toast('ボタンの位置をリセットしました');
      });
    });
  });
}
